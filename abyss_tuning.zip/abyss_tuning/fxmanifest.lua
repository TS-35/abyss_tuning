fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'abyss_tuning'
author 'Abyss'
description 'ECU yazılım, şanzıman, motor sesi, egzoz, dyno, tablet ve araç kumandası'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua',
}

client_scripts {
    'client/main.lua',
    'client/vehicle.lua',
    'client/effects.lua',
    'client/dyno.lua',
    'client/launchtest.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua',
}

ui_page 'web/index.html'

files {
    'web/index.html',
    'web/style.css',
    'web/app.js',
    'web/sounds/*.ogg',
}

dependencies {
    'qb-core',
    'ox_lib',
    'oxmysql',
}
