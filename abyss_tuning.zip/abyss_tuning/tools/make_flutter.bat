@echo off
rem Kendi kestigin bir kayittan flutter_real.ogg uretir (ffmpeg gerekli).
rem Kullanim:  make_flutter.bat girdi.mp4 baslangic sure
rem Ornek:     make_flutter.bat video.mp4 00:01:23.4 1.2
rem Cikan flutter_real.ogg dosyasini web\sounds\ klasorune koy, otomatik kullanilir.
ffmpeg -y -ss %2 -t %3 -i %1 -vn -ac 1 -ar 44100 -af "highpass=f=180,lowpass=f=12000,loudnorm=I=-16:TP=-1.5,afade=t=in:d=0.015,areverse,afade=t=in:d=0.25,areverse" -c:a libvorbis -q:a 5 flutter_real.ogg
echo Tamam: flutter_real.ogg
