# abyss_tuning

ECU yazılımı (Stock / Stage 1-4), şanzıman yazılımı, motor sesi, egzoz efektleri, dyno testi,
tablet arayüzü (ECU Studio tarzı) ve araç kumandası (item).

## Bağımlılıklar
`qb-core`, `ox_lib`, `oxmysql` (ox_target KULLANMAZ)

## Kurulum
1. Klasörü `resources/[abyss]/abyss_tuning` altına koy.
2. `server.cfg` içine `ensure abyss_tuning` ekle (ox_lib, oxmysql, qb-core'dan sonra).
3. Tablo ilk açılışta otomatik oluşur (`abyss_tuning`). İstersen `install.sql` dosyasını elle de çalıştırabilirsin.
4. Aşağıdaki item'ı `qb-core/shared/items.lua` dosyasına ekle (ox_inventory kullanıyorsan `ox_inventory/data/items.lua`).
5. Kumanda envanter görseli hazır: `inventory/abyss_keyfob.png` (256x256, şeffaf). Bunu envanterin görsel klasörüne kopyala
   (qb-inventory: `html/images`, ox_inventory: `web/images`).

### qb-core item
```lua
['abyss_keyfob'] = {
    name = 'abyss_keyfob', label = 'Araç Kumandası', weight = 100, type = 'item', image = 'abyss_keyfob.png',
    unique = false, useable = true, shouldClose = true,
    description = 'Sürüş modu, ESP ve egzoz kumandası',
},
```

### ox_inventory item
```lua
['abyss_keyfob'] = {
    label = 'Araç Kumandası', weight = 100, stack = false, close = true,
    description = 'Sürüş modu, ESP ve egzoz kumandası',
},
```
ox_inventory kullanıyorsan useable item için `server/main.lua` içindeki
`QBCore.Functions.CreateUseableItem` yerine ox_inventory export'u (`exports.ox_inventory:...`) veya
qb-core köprüsünün useable item desteğini kullan.

## Kullanım
- `/tuningtablet` : Araç içinde (sürücü koltuğu) tableti açar.
- Kumanda itemi : Yakındaki / içinde olduğun araca bağlanır. ECO, COMFORT, SPORT, SPORT+, ESP OFF, EXHAUST.
  Kısayollar: 1-4 mod, 5 ESP, 6 egzoz, ESC kapat.

## Ayarlar
Tüm stage, fiyat, şanzıman, motor sesi, mod ve ESP değerleri `config.lua` içinde.
`Config.AllowedJobs = {'mechanic'}` ile tableti mesleğe kısıtlayabilirsin.
`Config.RequireOwnedVehicle = true` ile sadece sahibi olduğun araçlara işlem yapılır.

## Notlar
- DLC motor sesleri için `Config.Sounds` içindeki `audio` alanını kendi ses paketinin audioName değerleriyle değiştir.
  Paket sunucuda yüklü değilse o ses çalışmaz (araç varsayılan sesine döner).
- Turbo, blow-off, flutter ve pop sesleri sürücünün kulağına NUI üzerinden çalar. Çevredeki oyuncular
  sadece pop/backfire ve duman particle efektlerini görür.
- ESP, GTA'da yerleşik olmadığı için simüle edilir: kapalıyken çekiş kaybı artar, açıkken aşırı savrulma sönümlenir.
- Güç/hız değerleri başlangıç ayarlarıdır; sunucu dengene göre `config.lua`'dan oyna.

## Stage / çekiş ayarı
- Her stage için `power`, `driveForce`, `topSpeed`, `shift`, `response`, `aero`, `grip`, `lowTraction` değerleri `Config.Stages` içinde.
- Stage 4'te patinaj çoksa: `lowTraction` değerini düşür (0.60 → 0.50), `grip` değerini artır, `Config.TC.cut` değerini küçült.
- Güç yetersizse: `power` ve `driveForce` değerlerini birlikte artır, tablodaki HP sayısı için `Config.Dyno.hpScale`.

## Efekt ayarları (`Config.Effects`)
- **Kara duman:** Egzoz sekmesinden "Black Smoke" açılır. Egzoz uçlarında siyaha boyanmış döngülü partikül çıkar, gaza basınca açılır (`smokeMinThrottle`), herkese senkron görünür.
  Duman beyaz/gri görünürse `smokeFx` listesine başka bir `core` partikül adı ekle, rengi `smokeColor` belirler.
- **Flutter / blow-off:** Sadece yüksek devirde (`minRpm`) tam gaz tutulurken (`minHold`) bir anda gaz kesilince (`suddenMs`) tek sefer çalar. Ses seviyesi `volume`, tekrar aralığı `cooldown`.
- **Popcorn aralığı:** `popCooldown` + rastgele `popJitter` (ms), olasılık `popChance`. Daha seyrek istersen bu değerleri artır.
- **Isınma:** Motor sağlığı `heatMinHealth` altına inmez, böylece oyunun varsayılan beyaz motor dumanı çıkmaz.

## Fren, kalkış menüsü ve egzoz vanası
- **BRAKES sekmesi:** Stock / Street / Sport / Race / Carbon fren kitleri (`Config.Brakes`: `force`, `handbrake`, fiyat) ve ABS (`Config.ABS`).
  Fren gücü `fBrakeForce`, el freni `fHandBrakeForce` ile uygulanır. ABS sert frenlemede aracı düz tutar. 100-0 mesafesi `Config.BaseStopMeters`'e göre tahmin edilir.
- **LAUNCH sekmesi:** Kalkış gücü (0-100) ve patinaj (0 = hiç patinaj, 100 = burnout) kaydırıcıları + hazır ayarlar (Smooth, Street, Sport, Drag, Burnout).
  Değerler FLASH ECU ile araca yazılır. Ayarlar: `Config.LaunchMenu`.
- **Egzoz vanası (kumanda EXHAUST):** Kapalıyken flutter, kara duman ve popcorn çalışmaz, egzoz stok gibi olur. `Config.Effects.closedValveStockSound = true` ise vana takılıyken kapatınca motor sesi de orijinale döner.
  Vana tabletten bir kez satın alınır, kumandadan kapatıp açmak tekrar ücret istemez.

## ECU SETTINGS sekmesi
Fotoğraftaki ECU Configuration ekranı: Fuel Map, Throttle Response (Comfort/Street/Sport/Race/Instant), Ignition Timing, Rev Limiter, Speed Limiter (+ Disable),
Launch Control, Anti-Lag (ALS), Pop & Bang Level, Engine Brake ve Idle RPM. "Apply & Flash ECU" ya da sağdaki FLASH ECU ile araca yazılır, "Reset to Default" varsayılana döner.
Hepsi `Config.EcuTune` içinde ayarlanır:
- **Fuel Map / Ignition:** ek güç ve ısınma çarpanı (zengin/avans = daha güçlü, daha sıcak).
- **Throttle Response:** `fDriveInertia` çarpanı + ek güç.
- **Rev Limiter:** ayarlanan RPM'de yakıt kesilir (kırmızı çizgi `redlineRpm`, varsayılan 9000). **Speed Limiter:** `SetVehicleMaxSpeed`.
- **Launch Control (2-step):** RPM en düşükte (2000) kapalı. Açıkken dururken fren + tam gaz ile devir tutulur, fren bırakılınca `lc.window` süre `lc.boost` kadar ek güç verir.
- **Anti-Lag:** gaz bırakınca turbo basıncı tutulur, egzoz vanası açıksa patlamalar gelir. **Pop & Bang:** Off/Street/Sport/Race çarpanları.
- **Engine Brake:** %50 fabrika, üstü daha çok yavaşlatır, altı daha az. **Idle RPM:** 750 fabrika.
- Egzoz vanası kumandadan kapalıysa flutter, duman, popcorn ve anti-lag patlamaları çalışmaz.

## Air Suspension (yeniden eklendi)
- **Tablet > SUSPENSION:** Kit $15.000 (`Config.Air.price`), "FIT KIT" ile satın alınır. Kit yokken kumandadaki AIR "Not fitted" der. Kit şartı istemezsen `Config.Air.requireKit = false`.
- **Kumanda AIR:** ˅ aşağı, ˄ yukarı, 5 seviye (Level 5 = normal, Level 1 = en alçak). Tek basış bir seviye, basılı tutunca yavaşça devam eder. Kısayol: 7 alçalt, 8 yükselt.
  Seviye `Config.Air.transition` (1.4 sn) boyunca yavaşça iner/çıkar. Alçalınca otomatik kamber, ~100 km/h üstünde araç kendini Level 3'e yükseltir.
- **Üç yöntem birlikte:** (1) araç "Suspension" modu: kademeli ve herkes görür, (2) `fSuspensionRaise` ile yumuşak ek alçalma (her adımda mod yenilenir),
  (3) tekerlek kamberi. Fazla alçalıyorsa `lowestRaise` değerini küçült (-0.07), hiç alçalmıyorsa `useSuspensionMod`/`useRaise` değerlerini kontrol et.
- **Teşhis:** Araçtayken `/airdebug` yaz. Araçta kaç suspension modu olduğunu, mevcut seviyeyi ve `fSuspensionRaise` değerini F8 konsoluna ve ekrana yazar.

## Güncelleme: düzeltmeler ve yeni özellikler
- **Radyo:** Araca binince ve motor çalışınca radyo kendiliğinden açılmaz (`Config.Radio.autoOff`). Kapatmak istemezsen `false` yap.
- **Hız takılması (ECU Settings sonrası):** (1) Devir limitörü artık sadece son viteste yakıt keser, alt viteslerde vites atmayı engellemez (`revLimitTopGearOnly`).
  (2) Çekiş kontrolü kayma oranına göre çalışır: yüksek hızda güç kesilip hız takılmaz (`Config.TC.maxRatio`). Hız limitörü yalnızca ayar açıkken devrede.
- **Launch Control 0-100 testi:** ECU Settings > Launch Control kartındaki ya da DYNO sekmesindeki "START 0-100 TEST" tableti kapatır.
  Ekranda "Hold BRAKE + THROTTLE" görünür, devir hedefe ulaşınca "READY · RELEASE THE BRAKE", fren bırakılınca süre başlar, 100 km/h'de biter.
  Sonuç (0-60 dahil) DYNO sekmesinde son 8 koşu olarak listelenir. İptal: BACKSPACE. Ayarlar: `Config.LaunchTest`.
- **Turbo kitleri (EXHAUST sekmesi):** Stock / Sport (küçük, hızlı dolar, tiz ıslık) / Race (büyük, geç dolar, güçlü) / Twin. Basınç dolunca güç çarpanı (boost²) ile araç bir anda basar,
  tam basınçta hafif kamera sarsıntısı olur. Ayarlar: `Config.Turbo` (`kick`, `torque`, `shake`).
- **Turbo sesi:** Oyunun kendi turbo sesi (native `SetVehicleTurboPressure` varsa) kullanılır. Yoksa basınç ve devire bağlı sürekli bir turbo sesi + blow-off NUI'de üretilir.
  Gerçek kayıt istersen `web/sounds/` içine `turbo_loop.ogg` (döngü) ve `blowoff_real.ogg` koy, otomatik kullanılır.
- **Air suspension:** Süspansiyon modunu artık sadece aracın ağ sahibi değiştirir (eskiden herkes değiştirip eski haline dönüyordu), yüksek hızda otomatik yükselme histerezislidir,
  oyuncunun kendi süspansiyon modu korunur. **Kumanda hatası:** AIR oklarına basılı tutma olayları düzeltildi (pad yeniden çizilince takılı kalıp sürekli adım atıyordu).
- **Diğer scriptler (mekanik sistemi):** `exports['abyss_tuning']:GetTune(plate)` ve `exports['abyss_tuning']:SetPart(plate, 'turbo', 'race')` ile takılan parçalar araca etki eder
  (turbo, brakes, stage, gearbox, sound, abs, flutter, smoke, valve, air).

## Flutter sesi
- Varsayılan `web/sounds/flutter.ogg` sentezdir (art arda kısa "tss" patlamaları, perde düşer, hafif yankı).
- Gerçek kayıt kullanmak için `web/sounds/flutter_real.ogg` dosyası koy, otomatik o çalar. Kendi kestiğin bir kaydı hazırlamak için `tools/make_flutter.bat` (Windows) ya da `tools/make_flutter.sh`:
  `make_flutter.bat video.mp4 00:01:23.4 1.2` (başlangıç zamanı ve süre). Kısa tutmak (1-1,5 sn) ve araç içinden / egzoza yakın çekilmiş bir kayıt seçmek en iyisi, uzaktan çekilenlerde yankı kalır.
- Sesi kısmak için `Config.Effects.flutter.volume`.

## ECU Kilidi (flash sırasında mini oyun)
FLASH ECU (ya da "Apply & Flash ECU") artık terminal ekranıyla başlar (`ecu-flash — stage_4.bin`, CAN-BUS, SEED REQUEST...). Seed isteğinden sonra **ECU Güvenlik Anahtarı** mini oyunu açılır:
- Hedef diziyi buffer'a yaz. İlk seçim en üst satırdan, sonra sırayla sütun ⇔ satır. Tablo her seferinde çözülebilir üretilir.
- Süre dolarsa, buffer dolarsa ya da hamle kalmazsa "ERİŞİM REDDEDİLDİ": flash yapılmaz, ücret alınmaz. Başarılıysa "ERİŞİM İZNİ VERİLDİ", terminal kalibrasyonu okur, yedek alır ve yeni haritayı yazar.
- ESC mini oyunu iptal eder (ceza yok).
- **Sunucu kontrolü:** Mini oyun geçilince sunucu 90 sn geçerli, tek kullanımlık bir bilet verir; flash bilet olmadan reddedilir. Çok hızlı (1,5 sn altı) bitirilen denemeler geçersiz sayılır, başarısızlıkta 6 sn bekleme vardır.
- Ayarlar `Config.EcuLock`: `enabled`, `time`, `buffer`, `grid`, `codes`, `lengthByStage` (stage yükseldikçe hedef dizi uzar: 3, 3, 3, 4, 5), `lockoutSeconds`, `skipJobs` (örn. `{'mechanic'}` mini oyunsuz flash yapar).
- Kapatmak için `Config.EcuLock.enabled = false` (terminal akışı yine çalışır, sadece mini oyun atlanır).
