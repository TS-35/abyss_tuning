local QBCore = exports['qb-core']:GetCoreObject()

local Default = {
    stage = 'stock', gearbox = 'standard', sound = 'oem',
    flutter = false, smoke = false, valve = false, valveOwned = false,
    mode = 'normal', esp = true,
    brakes = 'stock', abs = false,
    air = false, airLevel = 5,
    turbo = 'stock', runs = {},
    launchPower = Config.LaunchMenu.defaultPower, launchSlip = Config.LaunchMenu.defaultSlip,
}

-- ===== Veritabanı =====
CreateThread(function()
    MySQL.query.await([[
        CREATE TABLE IF NOT EXISTS `abyss_tuning` (
            `plate` VARCHAR(16) NOT NULL,
            `data` LONGTEXT NOT NULL,
            PRIMARY KEY (`plate`)
        )
    ]])
end)

-- ===== ECU ayarları: doğrulama =====
local function clampNum(v, lo, hi, def)
    v = tonumber(v)
    if not v then return def end
    return math.max(lo, math.min(hi, math.floor(v + 0.5)))
end

function Abyss_SanitizeEcu(e)
    local D, C = Config.EcuTune.defaults, Config.EcuTune
    e = type(e) == 'table' and e or {}
    return {
        fuel = clampNum(e.fuel, 0, 100, D.fuel),
        throttle = (C.throttle[e.throttle] and e.throttle) or D.throttle,
        timing = (C.timing[e.timing] and e.timing) or D.timing,
        revLimit = clampNum(e.revLimit, C.revLimit.min, C.revLimit.max, D.revLimit),
        speedLimit = clampNum(e.speedLimit, C.speedLimit.min, C.speedLimit.max, D.speedLimit),
        speedLimitOff = e.speedLimitOff ~= false,
        lcRpm = clampNum(e.lcRpm, C.lc.min, C.lc.max, D.lcRpm),
        als = e.als == true,
        pops = (C.pops[e.pops] and e.pops) or D.pops,
        engBrake = clampNum(e.engBrake, 0, 100, D.engBrake),
        idle = clampNum(e.idle, C.idle.min, C.idle.max, D.idle),
    }
end

local function ecuEqual(a, b)
    for k, v in pairs(a) do if b[k] ~= v then return false end end
    return true
end

local function normPlate(p)
    p = tostring(p or '')
    p = p:gsub('^%s+', ''):gsub('%s+$', '')
    return p:upper()
end

local function copyDefault()
    local t = {}
    for k, v in pairs(Default) do t[k] = v end
    return t
end

local function loadTune(plate)
    local row = MySQL.single.await('SELECT data FROM abyss_tuning WHERE plate = ?', { plate })
    local tune = copyDefault()
    if row and row.data then
        local ok, decoded = pcall(json.decode, row.data)
        if ok and type(decoded) == 'table' then
            for k, v in pairs(decoded) do tune[k] = v end
        end
    end
    if tune.valve then tune.valveOwned = true end   -- eski kayıtlar için
    tune.ecu = Abyss_SanitizeEcu(tune.ecu)
    if type(tune.runs) ~= 'table' then tune.runs = {} end
    if not Config.Turbo.kits[tune.turbo or 'stock'] then tune.turbo = 'stock' end
    return tune
end

local function saveTune(plate, tune)
    MySQL.insert.await(
        'INSERT INTO abyss_tuning (plate, data) VALUES (?, ?) ON DUPLICATE KEY UPDATE data = VALUES(data)',
        { plate, json.encode(tune) }
    )
end

local function setStateBag(netId, tune)
    if not netId then return end
    local veh = NetworkGetEntityFromNetworkId(netId)
    if veh and veh ~= 0 and DoesEntityExist(veh) then
        Entity(veh).state:set('abyss:tune', tune, true)
    end
end

-- ===== Yetki =====
local function hasAccess(src)
    if not Config.AllowedJobs or #Config.AllowedJobs == 0 then return true end
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return false end
    local job = Player.PlayerData.job and Player.PlayerData.job.name
    for _, j in ipairs(Config.AllowedJobs) do
        if j == job then return true end
    end
    return false
end

local function ownsVehicle(src, plate)
    if not Config.RequireOwnedVehicle then return true end
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return false end
    local row = MySQL.single.await(
        'SELECT 1 AS ok FROM player_vehicles WHERE plate = ? AND citizenid = ?',
        { plate, Player.PlayerData.citizenid }
    )
    return row ~= nil
end

-- ===== Seçim doğrulama & fiyat (sadece değişen parçalar ücretlendirilir) =====
local function soundExists(id)
    for _, s in ipairs(Config.Sounds) do
        if s.id == id then return true end
    end
    return false
end

local function clamp100(v, def)
    v = tonumber(v)
    if not v then return def end
    return math.max(0, math.min(100, math.floor(v + 0.5)))
end

local function validSelection(sel)
    if type(sel) ~= 'table' then return false end
    if not Config.Stages[sel.stage] then return false end
    if not Config.Gearboxes[sel.gearbox] then return false end
    if not Config.Brakes[sel.brakes or 'stock'] then return false end
    if not Config.Turbo.kits[sel.turbo or 'stock'] then return false end
    return soundExists(sel.sound)
end

local function soundPrice(id)
    for _, s in ipairs(Config.Sounds) do
        if s.id == id then return s.price end
    end
    return 0
end

local function calcPrice(current, sel)
    local total = 0
    if sel.stage ~= current.stage then total = total + Config.Stages[sel.stage].price end
    if sel.gearbox ~= current.gearbox then total = total + Config.Gearboxes[sel.gearbox].price end
    if sel.sound ~= current.sound then total = total + soundPrice(sel.sound) end
    for key, fx in pairs(Config.ExhaustFx) do
        if key == 'valve' then
            -- vana bir kez satın alınır; kumandadan kapatıp açmak tekrar ücret istemez
            if sel.valve and not current.valve and not current.valveOwned then total = total + fx.price end
        elseif sel[key] and not current[key] then
            total = total + fx.price
        end
    end
    local sb, cb = sel.brakes or 'stock', current.brakes or 'stock'
    if sb ~= cb then total = total + Config.Brakes[sb].price end
    if sel.abs and not current.abs then total = total + Config.ABS.price end
    local st, ct = sel.turbo or 'stock', current.turbo or 'stock'
    if st ~= ct then total = total + Config.Turbo.kits[st].price end
    if not ecuEqual(Abyss_SanitizeEcu(sel.ecu), Abyss_SanitizeEcu(current.ecu)) then total = total + (Config.EcuTune.price or 0) end
    return total
end

-- ===== ECU kilidi: minigame biletleri =====
local lockStart, lockTicket, lockOut = {}, {}, {}

local function lockSkip(src)
    if not Config.EcuLock.enabled then return true end
    local jobs = Config.EcuLock.skipJobs
    if not jobs or #jobs == 0 then return false end
    local Player = QBCore.Functions.GetPlayer(src)
    local job = Player and Player.PlayerData.job and Player.PlayerData.job.name
    for _, j in ipairs(jobs) do if j == job then return true end end
    return false
end

lib.callback.register('abyss_tuning:lock:begin', function(source)
    if lockSkip(source) then return { ok = true, skip = true } end
    local now = os.time()
    if lockOut[source] and lockOut[source] > now then
        return { ok = false, msg = ('Güvenlik kilidi: %d sn sonra tekrar dene.'):format(lockOut[source] - now) }
    end
    lockStart[source] = GetGameTimer()
    return { ok = true }
end)

lib.callback.register('abyss_tuning:lock:done', function(source, ok, cancelled)
    if lockSkip(source) then return { ok = true } end
    local started = lockStart[source]
    lockStart[source] = nil
    if not ok or not started then
        if not cancelled then lockOut[source] = os.time() + (Config.EcuLock.lockoutSeconds or 6) end
        return { ok = false }
    end
    if GetGameTimer() - started < (Config.EcuLock.minMs or 1500) then
        lockOut[source] = os.time() + (Config.EcuLock.lockoutSeconds or 6)
        return { ok = false }
    end
    lockTicket[source] = os.time() + (Config.EcuLock.ticketSeconds or 90)
    return { ok = true }
end)

AddEventHandler('playerDropped', function()
    local src = source
    lockStart[src], lockTicket[src], lockOut[src] = nil, nil, nil
end)

-- ===== Callback'ler =====
lib.callback.register('abyss_tuning:canOpen', function(source)
    return hasAccess(source)
end)

lib.callback.register('abyss_tuning:getTune', function(source, plate)
    plate = normPlate(plate)
    if plate == '' then return copyDefault() end
    return loadTune(plate)
end)

lib.callback.register('abyss_tuning:flash', function(source, netId, plate, sel)
    if not hasAccess(source) then return { ok = false, msg = 'Bu işlem için yetkin yok.' } end
    plate = normPlate(plate)
    if plate == '' or not validSelection(sel) then return { ok = false, msg = 'Geçersiz seçim.' } end
    if not ownsVehicle(source, plate) then return { ok = false, msg = 'Bu araç sana ait değil.' } end
    if not lockSkip(source) and (not lockTicket[source] or lockTicket[source] < os.time()) then
        return { ok = false, msg = 'ECU kilitli. Güvenlik anahtarını çözmen gerekiyor.' }
    end

    local current = loadTune(plate)
    local price = calcPrice(current, sel)

    local Player = QBCore.Functions.GetPlayer(source)
    if not Player then return { ok = false, msg = 'Oyuncu bulunamadı.' } end

    if price > 0 then
        local balance = Player.PlayerData.money[Config.PayWith] or 0
        if balance < price then
            return { ok = false, msg = ('Yetersiz bakiye. Gereken: $%s'):format(price) }
        end
        Player.Functions.RemoveMoney(Config.PayWith, price, 'abyss-tuning-ecu')
    end

    local tune = {
        stage = sel.stage, gearbox = sel.gearbox, sound = sel.sound,
        flutter = sel.flutter == true, smoke = sel.smoke == true, valve = sel.valve == true,
        valveOwned = current.valveOwned == true or sel.valve == true,
        brakes = sel.brakes or 'stock', abs = sel.abs == true,
        launchPower = clamp100(sel.launchPower, Config.LaunchMenu.defaultPower),
        launchSlip = clamp100(sel.launchSlip, Config.LaunchMenu.defaultSlip),
        ecu = Abyss_SanitizeEcu(sel.ecu),
        mode = current.mode, esp = current.esp,
        air = current.air, airLevel = current.airLevel,
        turbo = sel.turbo or 'stock', runs = current.runs,
    }
    saveTune(plate, tune)
    setStateBag(netId, tune)
    lockTicket[source] = nil                       -- bilet tek kullanımlık
    return { ok = true, tune = tune, price = price }
end)

-- Air suspension kit satın alma (ECU flash'tan bağımsız)
lib.callback.register('abyss_tuning:fitAir', function(source, netId, plate)
    if not hasAccess(source) then return { ok = false, msg = 'Bu işlem için yetkin yok.' } end
    plate = normPlate(plate)
    if plate == '' or not ownsVehicle(source, plate) then return { ok = false, msg = 'Bu araç sana ait değil.' } end

    local tune = loadTune(plate)
    if tune.air then return { ok = false, msg = 'Kit zaten takılı.' } end

    local Player = QBCore.Functions.GetPlayer(source)
    if not Player then return { ok = false, msg = 'Oyuncu bulunamadı.' } end

    local price = Config.Air.price
    if (Player.PlayerData.money[Config.PayWith] or 0) < price then
        return { ok = false, msg = ('Yetersiz bakiye. Gereken: $%s'):format(price) }
    end
    Player.Functions.RemoveMoney(Config.PayWith, price, 'abyss-tuning-air')

    tune.air = true
    tune.airLevel = Config.Air.levels
    saveTune(plate, tune)
    setStateBag(netId, tune)
    return { ok = true, tune = tune, price = price }
end)

-- ===== 0-100 sonuçları =====
lib.callback.register('abyss_tuning:saveRun', function(source, plate, run)
    plate = normPlate(plate)
    if plate == '' or type(run) ~= 'table' then return nil end
    local t100 = tonumber(run.t100)
    if not t100 or t100 < 0.8 or t100 > 60.0 then return nil end
    local tune = loadTune(plate)
    local t60 = tonumber(run.t60)
    table.insert(tune.runs, 1, {
        t100 = math.floor(t100 * 100 + 0.5) / 100,
        t60 = t60 and math.floor(t60 * 100 + 0.5) / 100 or nil,
        stage = Config.Stages[tune.stage] and tune.stage or 'stock',
        rpm = math.floor(tonumber(run.rpm) or 0),
        ts = os.time(),
    })
    while #tune.runs > (Config.LaunchTest.maxRuns or 8) do table.remove(tune.runs) end
    saveTune(plate, tune)
    return tune.runs
end)

-- ===== Diğer scriptler için (mekanik sistemi vb.): takılan parçalar araca etki etsin =====
-- exports['abyss_tuning']:GetTune(plate)
-- exports['abyss_tuning']:SetPart(plate, 'turbo', 'race')   -- turbo | brakes | stage | gearbox | sound | abs | flutter | smoke | valve | air
local PART_RULES = {
    turbo   = function(v) return Config.Turbo.kits[v] ~= nil end,
    brakes  = function(v) return Config.Brakes[v] ~= nil end,
    stage   = function(v) return Config.Stages[v] ~= nil end,
    gearbox = function(v) return Config.Gearboxes[v] ~= nil end,
    sound   = function(v) return soundExists(v) end,
    abs     = function(v) return type(v) == 'boolean' end,
    flutter = function(v) return type(v) == 'boolean' end,
    smoke   = function(v) return type(v) == 'boolean' end,
    valve   = function(v) return type(v) == 'boolean' end,
    air     = function(v) return type(v) == 'boolean' end,
}

local function findVehicleByPlate(plate)
    for _, v in ipairs(GetAllVehicles()) do
        if normPlate(GetVehicleNumberPlateText(v)) == plate then return v end
    end
    return nil
end

exports('GetTune', function(plate)
    plate = normPlate(plate)
    if plate == '' then return nil end
    return loadTune(plate)
end)

exports('SetPart', function(plate, key, value)
    plate = normPlate(plate)
    local rule = PART_RULES[key]
    if plate == '' or not rule or not rule(value) then return false end
    local tune = loadTune(plate)
    tune[key] = value
    if key == 'valve' and value then tune.valveOwned = true end
    if key == 'air' and value then tune.airLevel = tune.airLevel or Config.Air.levels end
    saveTune(plate, tune)
    local veh = findVehicleByPlate(plate)
    if veh and DoesEntityExist(veh) then Entity(veh).state:set('abyss:tune', tune, true) end
    return true
end)

-- ===== Araç kumandası =====
QBCore.Functions.CreateUseableItem(Config.FobItem, function(source)
    TriggerClientEvent('abyss_tuning:client:useFob', source)
end)

local function hasFob(src)
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return false end
    return Player.Functions.GetItemByName(Config.FobItem) ~= nil
end

lib.callback.register('abyss_tuning:fob:set', function(source, netId, plate, field, value)
    if not hasFob(source) then return { ok = false } end
    plate = normPlate(plate)
    if plate == '' or not ownsVehicle(source, plate) then return { ok = false } end

    local tune = loadTune(plate)
    if field == 'mode' then
        if not Config.Modes[value] then return { ok = false } end
        tune.mode = value
    elseif field == 'esp' then
        tune.esp = value == true
    elseif field == 'valve' then
        if value == true and not tune.valveOwned then
            return { ok = false, msg = 'Egzoz vanası takılı değil. Tabletten satın al.' }
        end
        tune.valve = value == true
    elseif field == 'airLevel' then
        if Config.Air.requireKit and not tune.air then
            return { ok = false, msg = 'Air suspension kiti takılı değil. Tabletten satın al.' }
        end
        value = math.floor(tonumber(value) or 0)
        if value < 1 or value > Config.Air.levels then return { ok = false } end
        tune.airLevel = value
    else
        return { ok = false }
    end

    saveTune(plate, tune)
    setStateBag(netId, tune)
    return { ok = true, tune = tune }
end)

-- Araç spawn olduğunda / yakına geldiğinde kayıtlı tune'u state bag'e yaz
RegisterNetEvent('abyss_tuning:server:requestSync', function(netId, plate)
    plate = normPlate(plate)
    if plate == '' then return end
    setStateBag(netId, loadTune(plate))
end)
