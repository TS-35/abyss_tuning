CREATE TABLE IF NOT EXISTS `abyss_tuning` (
  `plate` VARCHAR(16) NOT NULL,
  `data` LONGTEXT NOT NULL,
  PRIMARY KEY (`plate`)
);
