'use strict';

const RES = typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'abyss_tuning';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

function post(name, data = {}) {
  return fetch(`https://${RES}/${name}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify(data),
  }).then(r => r.json()).catch(() => ({}));
}

const money = n => '$' + Number(n).toLocaleString('tr-TR');
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const sign = n => (n > 0 ? '+' : '') + n + '%';

/* ===== Sounds ===== */
const SOUND_NAMES = ['click', 'beep', 'done', 'whoosh', 'blowoff', 'flutter', 'pop', 'hiss', 'comp'];
const sounds = {};
SOUND_NAMES.forEach(n => { const a = new Audio(`sounds/${n}.ogg`); a.preload = 'auto'; sounds[n] = a; });
// Gerçek flutter kaydı (web/sounds/flutter_real.ogg) varsa sentez yerine o çalar
(() => {
  const a = new Audio('sounds/flutter_real.ogg');
  a.preload = 'auto';
  a.addEventListener('canplaythrough', () => { sounds.flutter = a; }, { once: true });
})();

function play(name, volume = 0.6) {
  const base = sounds[name];
  if (!base) return;
  const a = base.cloneNode();
  a.volume = Math.max(0, Math.min(1, volume));
  a.play().catch(() => {});
}

/* ===== State ===== */
const S = {
  cfg: null, base: null, plate: '', installed: null, sel: null,
  tab: 'stage', query: '', clockTimer: null, started: 0, dynoTimer: null,
  dyno: null, dynoRunning: false, flashing: false,
};

const ICON = {
  search: '<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg>',
  refresh: '<svg viewBox="0 0 24 24"><path d="M20 12a8 8 0 1 1-2.3-5.7M20 4v5h-5"/></svg>',
  key: '<svg viewBox="0 0 24 24"><circle cx="8" cy="15" r="4"/><path d="m11 12 8-8M16 7l3 3"/></svg>',
  check: '<svg viewBox="0 0 24 24"><path d="m5 12 5 5 9-10"/></svg>',
  flutter: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="2"/><path d="M12 10c-1-4 0-7 3-7M14 12c4-1 7 0 7 3M12 14c1 4 0 7-3 7M10 12c-4 1-7 0-7-3"/></svg>',
  smoke: '<svg viewBox="0 0 24 24"><path d="M6 18a4 4 0 0 1 0-8 5 5 0 0 1 9.6-1A4.5 4.5 0 0 1 17 18z"/></svg>',
  valve: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/><path d="M12 4a8 8 0 0 1 0 16z" fill="currentColor"/></svg>',
  leaf: '<svg viewBox="0 0 24 24"><path d="M5 19c0-9 6-14 15-14 0 9-5 15-14 15zM5 19l8-8"/></svg>',
  car: '<svg viewBox="0 0 24 24"><path d="M4 15v-3l2-5h12l2 5v3zM4 15v3h3v-3M17 15v3h3v-3"/><circle cx="8" cy="13" r=".6"/><circle cx="16" cy="13" r=".6"/></svg>',
  gauge: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/><path d="M12 12l3-4M7 14h1M12 7v1M17 14h-1"/></svg>',
  flag: '<svg viewBox="0 0 24 24"><path d="M5 21V4M5 4h13l-3 4 3 4H5"/></svg>',
  esp: '<svg viewBox="0 0 24 24"><path d="M8 18v-5l1.5-3h5L16 13v5zM6 21h12M7 6l-2-2M17 6l2-2"/></svg>',
  exhaust: '<svg viewBox="0 0 24 24"><path d="M3 12c0-3 3-3 4.5 0s4.5 3 6 0 4.5-3 6 0-1.5 3-3 0M3 12c0 3 3 3 4.5 0"/></svg>',
  down: '<svg viewBox="0 0 24 24"><path d="m6 9 6 6 6-6"/></svg>',
  up: '<svg viewBox="0 0 24 24"><path d="m6 15 6-6 6 6"/></svg>',
  brake: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="2.5"/><path d="M12 4v3M12 17v3M4 12h3M17 12h3"/></svg>',
  chip: '<svg viewBox="0 0 24 24"><rect x="7" y="7" width="10" height="10" rx="1.5"/></svg>',
};

/* ===== Messages from Lua ===== */
window.addEventListener('message', e => {
  const { action, data } = e.data || {};
  switch (action) {
    case 'openTablet': openTablet(data); break;
    case 'openFob': openFob(data); break;
    case 'close': hideAll(); break;
    case 'sound': play(data.name, data.volume); break;
    case 'dynoStart': startDyno(data); break;
    case 'dynoEnd': endDyno(); break;
    case 'turbo': Turbo.update(data); break;
    case 'turboBlow': Turbo.blow(data); break;
    case 'launchHud': showLaunchHud(data); break;
  }
});

function hideAll() {
  airHoldStop();
  $('#tablet').classList.add('hidden');
  $('#fob').classList.add('hidden');
  clearInterval(S.clockTimer);
  clearInterval(S.dynoTimer);
  S.flashing = false;
}

/* ===================== TABLET ===================== */
function selFromTune(t) {
  return { stage: t.stage, gearbox: t.gearbox, sound: t.sound, flutter: !!t.flutter, smoke: !!t.smoke, valve: !!t.valve,
    brakes: t.brakes || 'stock', abs: !!t.abs, turbo: t.turbo || 'stock',
    launchPower: t.launchPower == null ? 70 : t.launchPower, launchSlip: t.launchSlip == null ? 0 : t.launchSlip,
    ecu: { ...(S.cfg.ecuTune.defaults), ...(t.ecu || {}) } };
}

function openTablet(d) {
  S.cfg = d.config; S.base = d.base; S.plate = d.plate;
  S.installed = { ...d.tune };
  S.sel = selFromTune(d.tune);
  S.tab = 'stage'; S.query = ''; S.dyno = null; S.dynoRunning = false; S.flashing = false;

  $('#vName').textContent = (d.base.name || 'Vehicle').toUpperCase();
  $('#vPlate').textContent = d.plate;

  $$('#tabs button').forEach(b => b.classList.toggle('on', b.dataset.tab === 'stage'));
  $('#tablet').classList.remove('hidden');
  $('#fob').classList.add('hidden');
  Term.close();
  $('#lock').classList.add('hidden');
  $('#toast').classList.add('hidden');

  S.started = Date.now();
  clearInterval(S.clockTimer);
  const tick = () => {
    const now = new Date();
    $('#clock').textContent = String(now.getHours()).padStart(2, '0') + ':' + String(now.getMinutes()).padStart(2, '0');
  };
  tick();
  S.clockTimer = setInterval(tick, 15000);

  play('beep', 0.4);
  render();
}

$('#closeBtn').addEventListener('click', () => { if (!S.flashing) { play('click', 0.4); post('close'); } });
$$('#tabs button').forEach(b => b.addEventListener('click', () => {
  if (S.flashing) return;
  S.tab = b.dataset.tab;
  $$('#tabs button').forEach(x => x.classList.toggle('on', x === b));
  play('click', 0.35);
  render();
}));
document.addEventListener('keydown', e => {
  if (!$('#tablet').classList.contains('hidden')) {
    if (e.key === 'Escape') { if (Lock.active) Lock.cancel(); else if (!S.flashing) post('close'); }
  } else if (!$('#fob').classList.contains('hidden')) {
    fobKey(e);
  }
});

/* ===== Calculations ===== */
function stageOf(id) { return S.cfg.stages[id]; }

function preview() {
  const st = stageOf(S.sel.stage), gb = S.cfg.gearboxes[S.sel.gearbox];
  const b = S.base;
  const hp = Math.round(b.hp * (1 + st.powerPct / 100));
  const tq = Math.round(b.torque * (1 + st.powerPct / 100));
  const top = Math.round(b.topSpeed * st.topSpeed);
  const shift = +(st.shift * gb.shift).toFixed(2);
  const resp = Math.round(100 / st.response);
  return {
    hp, tq, top, shift, resp,
    powerPct: st.powerPct,
    speedPct: Math.round((st.topSpeed - 1) * 100),
    shiftPct: Math.round((shift - 1) * 100),
    delta: hp - b.hp,
  };
}

function totalPrice() {
  const c = S.cfg, i = S.installed, s = S.sel;
  let t = 0;
  if (s.stage !== i.stage) t += c.stages[s.stage].price;
  if (s.gearbox !== i.gearbox) t += c.gearboxes[s.gearbox].price;
  if (s.sound !== i.sound) t += (c.sounds.find(x => x.id === s.sound) || {}).price || 0;
  for (const k of Object.keys(c.exhaust)) {
    if (k === 'valve') { if (s.valve && !i.valve && !i.valveOwned) t += c.exhaust.valve.price; }
    else if (s[k] && !i[k]) t += c.exhaust[k].price;
  }
  if ((s.brakes || 'stock') !== (i.brakes || 'stock')) t += c.brakes[s.brakes].price;
  if (s.abs && !i.abs) t += c.abs.price;
  if ((s.turbo || 'stock') !== (i.turbo || 'stock')) t += c.turbo.kits[s.turbo].price;
  if (JSON.stringify(ecuOf(i)) !== JSON.stringify(ecuOf(s))) t += c.ecuTune.price || 0;
  return t;
}

const ECU_KEYS = ['fuel','throttle','timing','revLimit','speedLimit','speedLimitOff','lcRpm','als','pops','engBrake','idle'];
function ecuOf(x) {
  const d = S.cfg.ecuTune.defaults, e = x.ecu || {};
  const o = {};
  ECU_KEYS.forEach(k => { o[k] = e[k] == null ? d[k] : e[k]; });
  return o;
}

function isDirty() {
  const i = S.installed, s = S.sel;
  if (i.stage !== s.stage || i.gearbox !== s.gearbox || i.sound !== s.sound) return true;
  if (JSON.stringify(ecuOf(i)) !== JSON.stringify(ecuOf(s))) return true;
  if ((i.turbo || 'stock') !== (s.turbo || 'stock')) return true;
  if ((i.brakes || 'stock') !== (s.brakes || 'stock')) return true;
  if ((i.launchPower == null ? 70 : i.launchPower) !== s.launchPower || (i.launchSlip == null ? 0 : i.launchSlip) !== s.launchSlip) return true;
  return ['flutter', 'smoke', 'valve', 'abs'].some(k => !!i[k] !== !!s[k]);
}

/* ===== Right panel ===== */
function renderSide() {
  const st = stageOf(S.sel.stage);
  document.documentElement.style.setProperty('--ac', st.color);

  const p = preview();
  const ratio = Math.min(1, p.hp / (S.base.hp * 2.3));
  $('#gFg').style.strokeDasharray = `${Math.round(387 * ratio)} 516`;
  $('#gHp').textContent = p.hp;
  const dEl = $('#gDelta');
  if (p.delta > 0) { dEl.textContent = '+' + p.delta + ' HP'; dEl.className = 'up'; }
  else { dEl.textContent = 'STOCK'; dEl.className = ''; }

  const row = (k, v, d) => `<div><dt>${k}</dt><dd>${v}${d ? `<i>${d}</i>` : ''}</dd></div>`;
  $('#stats').innerHTML =
    row('Torque', p.tq + ' Nm', p.powerPct ? sign(p.powerPct) : '') +
    row('Top Speed', p.top + ' km/h', p.speedPct ? sign(p.speedPct) : '') +
    row('Shift Speed', 'x' + p.shift.toFixed(2), p.shiftPct ? sign(p.shiftPct) : '');

  const snd = S.cfg.sounds.find(x => x.id === S.sel.sound);
  const mode = S.cfg.modes[S.installed.mode] || { label: 'Comfort' };
  $('#chips').innerHTML =
    chip('STAGE', st.label) +
    chip('GEARBOX', S.cfg.gearboxes[S.sel.gearbox].label) +
    chip('ENGINE SOUND', snd ? snd.label : '—') +
    chip('BRAKES', S.cfg.brakes[S.sel.brakes].label + (S.sel.abs ? ' + ABS' : '')) +
    chip('LAUNCH', launchLabel(S.sel.launchPower, S.sel.launchSlip)) +
    chip('DRIVE MODE', mode.label);

  const dirty = isDirty();
  $('#dirty').classList.toggle('hidden', !dirty);
  $('#flashBtn').disabled = !dirty || S.flashing;
  $('#flashSub').textContent = dirty ? 'Total: ' + money(totalPrice()) : 'Write the selection to the car';
}
const chip = (k, v) => `<div><small>${esc(k)}</small><b>${esc(v)}</b></div>`;

/* ===== Tabs ===== */
function render() {
  renderSide();
  const m = $('#main');
  m.style.overflow = S.tab === 'sound' ? 'hidden' : 'auto';
  if (S.tab === 'stage') m.innerHTML = viewStage();
  else if (S.tab === 'ecu') m.innerHTML = viewEcu();
  else if (S.tab === 'gearbox') m.innerHTML = viewGearbox();
  else if (S.tab === 'sound') m.innerHTML = viewSound();
  else if (S.tab === 'exhaust') m.innerHTML = viewExhaust();
  else if (S.tab === 'suspension') m.innerHTML = viewSuspension();
  else if (S.tab === 'brakes') m.innerHTML = viewBrakes();
  else if (S.tab === 'launch') m.innerHTML = viewLaunch();
  else if (S.tab === 'dyno') { m.innerHTML = viewDyno(); drawChart(S.dyno ? 1 : 0); }
  bindMain();
}

/* --- STAGE --- */
function polar(cx, cy, r, a) {
  const rad = a * Math.PI / 180;
  return [cx + r * Math.sin(rad), cy - r * Math.cos(rad)];
}
function arc(cx, cy, r, a1, a2) {
  const [x1, y1] = polar(cx, cy, r, a1), [x2, y2] = polar(cx, cy, r, a2);
  return `M${x1.toFixed(1)} ${y1.toFixed(1)} A${r} ${r} 0 ${(a2 - a1) > 180 ? 1 : 0} 1 ${x2.toFixed(1)} ${y2.toFixed(1)}`;
}
const NEEDLE = [-42, 0, 26, 60, 84];
function dialSvg(idx) {
  let ticks = '';
  for (let i = 0; i <= 6; i++) {
    const a = -130 + i * (260 / 6);
    const [x1, y1] = polar(60, 58, 45, a), [x2, y2] = polar(60, 58, 50, a);
    ticks += `<line class="tick" x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}"/>`;
  }
  return `<svg viewBox="0 0 120 100">
    <path class="arc" d="${arc(60, 58, 38, -130, 92)}"/>
    <path class="arc red" d="${arc(60, 58, 38, 100, 130)}"/>
    ${ticks}
    <line class="needle" x1="60" y1="58" x2="60" y2="28" style="transform:rotate(${NEEDLE[idx]}deg);transform-origin:60px 58px"/>
    <circle class="hub" cx="60" cy="58" r="4.5"/>
  </svg>`;
}

function viewStage() {
  const c = S.cfg;
  const cur = c.stages[S.sel.stage];
  const rank = c.stageOrder.indexOf(S.sel.stage);
  const bars = Array.from({ length: 5 }, (_, i) => `<i class="${i <= rank ? 'on' : ''}" style="height:${12 + i * 6}px"></i>`).join('');

  const cards = c.stageOrder.map((id, idx) => {
    const s = c.stages[id];
    const hp = Math.round(S.base.hp * (1 + s.powerPct / 100));
    const inst = S.installed.stage === id;
    const isStock = id === 'stock';
    return `<button class="stage ${S.sel.stage === id ? 'sel' : ''}" data-stage="${id}" style="--c:${s.color}">
      <div class="tag">${esc(s.tag)}</div>
      <div class="dial">${dialSvg(idx)}<div class="num">${idx}</div></div>
      <div class="ttl">${esc(s.title)}</div>
      <div class="foot">
        <div class="hpl"><span class="hp">${hp}<small>HP</small></span>${isStock ? '' : `<span class="pct">${sign(s.powerPct)}</span>`}</div>
        <div class="pr">${isStock ? 'FREE' : money(s.price)}${inst ? `<span class="inst">✓ INSTALLED</span>` : ''}</div>
      </div>
    </button>`;
  }).join('');

  const p = preview(), b = S.base;
  const rows = [
    ['Estimated Power', p.hp, b.hp, p.hp + ' HP', b.hp * 2.4],
    ['Torque', p.tq, b.torque, p.tq + ' Nm', b.torque * 2.4],
    ['Top Speed', p.top, b.topSpeed, p.top + ' km/h', b.topSpeed * 1.8],
    ['Shift Speed', p.shift, 1, 'x' + p.shift.toFixed(2), 5],
    ['Rev Response', p.resp, 100, p.resp + '%', 170],
  ].map(([label, val, stock, text, max]) => {
    const d = Math.round((val / stock - 1) * 100);
    return `<div class="rw"><label>${label}</label>
      <div class="trk"><b style="width:${Math.min(100, val / max * 100).toFixed(1)}%"></b><u style="left:${Math.min(100, stock / max * 100).toFixed(1)}%"></u></div>
      <div class="v">${text}</div><div class="d ${d ? '' : 'z'}">${d ? sign(d) : '—'}</div></div>`;
  }).join('');

  return `
    <div class="head-row"><div><div class="eyebrow">ECU SOFTWARE</div><h1 class="h1">Performance Stage</h1></div><div class="bars-ico">${bars}</div></div>
    <div class="stages">${cards}</div>
    <div class="detail">
      <div>
        <div class="eyebrow">${esc(cur.label.toUpperCase())}</div>
        <h3>${esc(cur.title)}</h3>
        <p>${esc(cur.desc)}</p>
        <div class="legend2"><span><i class="a"></i>STOCK</span><span><i class="b"></i>SELECTED</span></div>
      </div>
      <div class="rows">${rows}</div>
    </div>`;
}

/* --- GEARBOX --- */
function patternSvg(kind) {
  if (kind === 'seq') {
    return `<svg viewBox="0 0 100 100">
      <path d="M58 40V22M52 28l6-6 6 6M58 60v18M52 72l6 6 6-6"/>
      <circle class="kn" cx="40" cy="50" r="5.5"/>
      <text x="62" y="54" font-size="10" fill="currentColor" stroke="none">N</text>
      <text x="55" y="14" font-size="10" fill="currentColor" stroke="none">+</text>
      <text x="56" y="92" font-size="12" fill="currentColor" stroke="none">−</text></svg>`;
  }
  return `<svg viewBox="0 0 100 100">
    <path d="M22 30V72M42 30V72M62 30V72M82 30V72M22 51H82"/>
    <circle class="kn" cx="22" cy="30" r="5.5"/>
    <g fill="currentColor" stroke="none" font-size="10" text-anchor="middle">
      <text x="22" y="20">1</text><text x="42" y="20">3</text><text x="62" y="20">5</text><text x="82" y="20">R</text>
      <text x="22" y="88">2</text><text x="42" y="88">4</text><text x="62" y="88">6</text></g></svg>`;
}

function viewGearbox() {
  const c = S.cfg;
  const cards = c.gearboxOrder.map(id => {
    const g = c.gearboxes[id];
    const ms = Math.round(c.baseShiftMs / g.shift);
    const on = Math.max(1, Math.round(g.shift / 3.5 * 10));
    const segs = Array.from({ length: 10 }, (_, i) => `<i class="${i < on ? 'on' : ''}"></i>`).join('');
    return `<button class="gb ${S.sel.gearbox === id ? 'sel' : ''}" data-gear="${id}">
      <div class="pat">${patternSvg(g.pattern)}</div>
      <div class="info">
        <div class="nm"><h4>${esc(g.label)}</h4><span class="price">${g.price ? money(g.price) : 'FREE'}</span></div>
        <p>${esc(g.desc)}</p>
        <div class="meter"><div class="ms">${ms}<small>ms</small></div>
          <div class="sp">SHIFT SPEED <b>x${g.shift.toFixed(1)}</b><div class="segs">${segs}</div></div></div>
      </div></button>`;
  }).join('');
  return `<div class="eyebrow">DRIVETRAIN</div><h1 class="h1">Gearbox Software</h1><div class="cards2">${cards}</div>`;
}

/* --- ENGINE SOUND --- */
function waveBars(id) {
  let h = 0; for (const ch of id) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  let out = '';
  const N = 14;
  for (let i = 0; i < N; i++) {
    h = (h * 1103515245 + 12345) >>> 0;
    const env = Math.sin(Math.PI * (i + 0.5) / N);               // ortada yüksek, kenarda alçak
    const px = Math.round(4 + env * (4 + (h >> 10) % 11));
    out += `<i style="height:${px}px"></i>`;
  }
  return `<div class="wv">${out}</div>`;
}

function viewSound() {
  const q = S.query.trim().toLowerCase();
  const list = S.cfg.sounds.filter(s => !q || (s.label + ' ' + (s.sub || '') + ' ' + (s.eng || '')).toLowerCase().includes(q));
  const groups = ['OEM', 'GTA V', 'DLC'];
  const item = s => `
    <button class="snd ${S.sel.sound === s.id ? 'sel' : ''}" data-snd="${s.id}">
      ${waveBars(s.id)}
      <div class="tx"><b>${esc(s.label)}</b>${s.sub ? `<span>${esc(s.sub)}</span>` : ''}</div>
      ${s.eng ? `<em>${esc(s.eng)}</em>` : ''}
    </button>`;
  const body = groups.map(g => {
    const rows = list.filter(s => s.group === g);
    if (!rows.length) return '';
    return `<div class="grp">${g}</div><div class="sgrid">${rows.map(item).join('')}</div>`;
  }).join('');
  return `
    <div class="sound-head">
      <div><div class="eyebrow">SOUND PROFILE</div><h1 class="h1" style="margin:4px 0 0">Engine Sound</h1></div>
      <label class="search">${ICON.search}<input id="sndSearch" placeholder="Search engine... (V8, RB26, Ferrari)" value="${esc(S.query)}"><small>${list.length}/${S.cfg.sounds.length}</small></label>
    </div>
    <div class="snd-scroll" style="height:calc(100% - 82px)">${body || '<div class="grp">NO RESULTS</div>'}</div>`;
}

/* --- EXHAUST --- */
function pill(x, y, w, text, on) {
  return `<g class="lbl ${on ? 'on' : ''}" transform="translate(${x} ${y})"><rect width="${w}" height="24" rx="12"/><circle cx="13" cy="12" r="3"/><text x="24" y="16">${text}</text></g>`;
}

function exhaustDiagram() {
  const s = S.sel;
  let blades = '';
  for (let i = 0; i < 6; i++) blades += `<path d="M262 142C256 131 262 122 273 124" transform="rotate(${i * 60} 262 142)"/>`;
  return `<div class="diagram ${s.valve ? 'valve-on' : ''} ${s.flutter ? 'flutter-on' : ''}">
  <svg viewBox="0 0 880 292" preserveAspectRatio="xMidYMid meet">
    <rect class="box" x="70" y="98" width="140" height="96" rx="10"/>
    <g stroke="#8a8a96"><circle cx="98" cy="122" r="9"/><circle cx="126" cy="122" r="9"/><circle cx="154" cy="122" r="9"/><circle cx="182" cy="122" r="9"/>
    <path d="M88 154H192M88 168H192"/></g>
    <g stroke="#8a8a96" fill="none"><path d="M212 118C232 118 238 134 238 142"/><path d="M212 134C226 134 234 140 238 142"/><path d="M212 150C226 150 234 146 238 142"/><path d="M212 166C232 166 238 150 238 142"/></g>
    <circle cx="262" cy="142" r="26" fill="#14141a" stroke="#8a8a96"/>
    <g class="fan">${blades}</g>
    <path class="pipe" d="M284 154C312 178 322 192 352 192L690 192"/>
    <path class="pipe-in" d="M284 154C312 178 322 192 352 192L690 192"/>
    <rect class="box" x="410" y="176" width="112" height="32" rx="15"/>
    <g class="valve"><circle cx="600" cy="192" r="13"/><circle cx="600" cy="192" r="3" fill="#e6e6ec" stroke="none"/></g>
    <rect class="box" x="680" y="156" width="132" height="72" rx="10"/>
    <g stroke="#e6e6ec" fill="none"><ellipse cx="836" cy="174" rx="8" ry="9"/><ellipse cx="836" cy="210" rx="8" ry="9"/></g>
    <path d="M812 174H828M812 210H828" stroke="#8a8a96" stroke-width="5"/>
    ${pill(296, 98, 108, 'Turbo Flutter', s.flutter)}
    ${pill(722, 114, 98, 'Black Smoke', s.smoke)}
    ${pill(548, 226, 112, 'Exhaust Valve', s.valve)}
    ${pill(752, 250, 84, 'Popcorn', s.valve)}
  </svg></div>`;
}

/* --- ECU SETTINGS --- */
function ecuCard(color, title, pill, pillColor, body, id) {
  return `<div class="ec" ${id ? `id="${id}"` : ''}>
    <div class="ech"><div class="ect"><i style="--d:${color}"></i>${title}</div>${pill != null ? `<span class="epill" style="${pillColor ? `--pc:${pillColor}` : ''}" data-pill="${id || ''}">${pill}</span>` : ''}</div>${body}</div>`;
}
const fuelText = v => v < 35 ? 'Lean — cooler, less power.' : v > 65 ? 'Rich — more power, runs hotter.' : 'Stoichiometric (λ1.0) — balanced performance.';
const lcText = (v, min) => v <= min ? 'OFF' : v + ' RPM';

function ecuRange(key, min, max, step, val) {
  return `<input type="range" data-ecu="${key}" min="${min}" max="${max}" step="${step}" value="${val}" style="--p:${((val - min) / (max - min) * 100).toFixed(1)}%">`;
}
function ecuBtns(key, opts, val) {
  return `<div class="ebtns">${opts.map(([id, label]) => `<button data-ecubtn="${key}:${id}" class="${val === id ? 'on' : ''}">${esc(label)}</button>`).join('')}</div>`;
}

function viewEcu() {
  const C = S.cfg.ecuTune, e = S.sel.ecu;
  const left = [
    ecuCard('#ff9f43', 'Fuel Map', e.fuel, null,
      `<div class="escale"><span>LEAN</span><span>STOICH</span><span>RICH</span></div>${ecuRange('fuel', 0, 100, 1, e.fuel)}<div class="edesc" id="fuelDesc">${fuelText(e.fuel)}</div>`, 'cFuel'),
    ecuCard('#f5d442', 'Throttle Response', null, null,
      ecuBtns('throttle', C.throttleOrder.map(id => [id, C.throttle[id].label]), e.throttle)),
    ecuCard('#ffd24d', 'Ignition Timing', null, null,
      ecuBtns('timing', C.timingOrder.map(id => [id, (id === 'retarded' ? '◄ ' : id === 'advanced' ? '' : '■ ') + C.timing[id].label + (id === 'advanced' ? ' ►' : '')]), e.timing)),
    ecuCard('#ff4d6d', 'Rev Limiter', e.revLimit + ' RPM', '#ff4d6d',
      ecuRange('revLimit', C.revLimit.min, C.revLimit.max, C.revLimit.step, e.revLimit), 'cRev'),
    ecuCard('#7cf08a', 'Speed Limiter', e.speedLimit + ' KPH', null,
      ecuRange('speedLimit', C.speedLimit.min, C.speedLimit.max, C.speedLimit.step, e.speedLimit) +
      `<div class="slim erow"><span>Disable Speed Limiter</span><button class="tsw ${e.speedLimitOff ? 'on' : ''}" data-ecutoggle="speedLimitOff" aria-label="Disable speed limiter"></button></div>`, 'cSpd'),
  ].join('');
  const right = [
    ecuCard('#7cf08a', 'Launch Control', lcText(e.lcRpm, C.lc.min), '#7cf08a',
      ecuRange('lcRpm', C.lc.min, C.lc.max, C.lc.step, e.lcRpm) +
      `<button class="lcbtn" data-lctest>▶ START 0-100 LAUNCH TEST</button>`, 'cLc'),
    ecuCard('#ff6b3d', 'Anti-Lag System', null, null,
      `<div class="erow"><div><b>Anti-Lag (ALS)</b><small>Maintains turbo spool during lift-off</small></div><button class="tsw ${e.als ? 'on' : ''}" data-ecutoggle="als" aria-label="Anti-lag"></button></div>`),
    ecuCard('#ff4d6d', 'Pop &amp; Bang Level', null, null,
      ecuBtns('pops', C.popsOrder.map(id => [id, C.pops[id].label]), e.pops)),
    ecuCard('#ffa94d', 'Engine Brake', e.engBrake + '%', null,
      ecuRange('engBrake', 0, 100, 1, e.engBrake), 'cEb'),
    ecuCard('#cfd3da', 'Idle RPM', e.idle + ' RPM', null,
      ecuRange('idle', C.idle.min, C.idle.max, C.idle.step, e.idle), 'cIdle'),
  ].join('');
  return `
    <div class="head-row"><div><h1 class="h1" style="margin-bottom:2px">ECU Configuration</h1><div class="eyebrow" style="letter-spacing:.08em;font-weight:500">Advanced engine calibration parameters</div></div></div>
    <div class="ecu-cols" style="margin-top:14px"><div class="ecol">${left}</div><div class="ecol">${right}</div></div>
    <div class="eact"><button class="ghost" id="ecuReset">↺ Reset to Default</button><button class="go" id="ecuApply" ${isDirty() ? '' : 'disabled'}>▶ Apply &amp; Flash ECU</button></div>`;
}

function updateEcuPills() {
  const C = S.cfg.ecuTune, e = S.sel.ecu;
  const set = (id, text) => { const el = document.querySelector(`[data-pill="${id}"]`); if (el) el.textContent = text; };
  set('cFuel', e.fuel); set('cRev', e.revLimit + ' RPM'); set('cSpd', e.speedLimit + ' KPH');
  set('cLc', lcText(e.lcRpm, C.lc.min)); set('cEb', e.engBrake + '%'); set('cIdle', e.idle + ' RPM');
  const fd = $('#fuelDesc'); if (fd) fd.textContent = fuelText(e.fuel);
  const ap = $('#ecuApply'); if (ap) ap.disabled = !isDirty();
}

/* --- SUSPENSION --- */
function viewSuspension() {
  const needKit = S.cfg.air.requireKit !== false;
  const fitted = !!S.installed.air || !needKit;
  const lv = S.cfg.air.levels;
  const cur = S.installed.airLevel || lv;
  const bars = Array.from({ length: lv }, (_, i) => `<i class="${fitted ? (i < cur ? 'on' : '') : 'on'}" style="height:${10 + i * 5}px"></i>`).join('');
  const art = `<svg viewBox="0 0 320 250">
    <path d="M18 24H302V112H240A80 80 0 0 0 80 112H18Z" fill="#17171d" stroke="#6b6b78"/>
    <g fill="#14141a" stroke="#d6d6de"><rect x="146" y="30" width="28" height="13" rx="6"/><rect x="146" y="46" width="28" height="13" rx="6"/><rect x="146" y="62" width="28" height="13" rx="6"/></g>
    <path d="M160 76V96" stroke="#d6d6de" stroke-width="3"/>
    <path d="M174 52C208 52 210 66 236 62" stroke="#d6d6de"/>
    <rect x="234" y="52" width="30" height="22" rx="5" fill="#14141a" stroke="#d6d6de"/><circle cx="249" cy="63" r="4" stroke="#d6d6de"/>
    <circle cx="160" cy="150" r="56" fill="#0d0d11" stroke="#e6e6ec" stroke-width="2.2"/>
    <circle cx="160" cy="150" r="42" stroke="#e6e6ec"/>
    <g stroke="#e6e6ec"><path d="M160 108V192M118 150H202M130 120l60 60M190 120l-60 60"/></g>
    <circle cx="160" cy="150" r="7" fill="#0d0d11" stroke="#e6e6ec" stroke-width="2"/>
    <path d="M18 212H302" stroke="#6b6b78"/>
  </svg>`;
  const check = t => `<li>${ICON.check}<span>${t}</span></li>`;
  return `
    <div class="head-row"><div><div class="eyebrow">CHASSIS</div><h1 class="h1" style="margin-bottom:14px">Air Suspension</h1></div>
      <span class="badge ${fitted ? 'on' : ''}">${fitted ? (needKit ? 'FITTED' : 'STANDARD') : 'NOT FITTED'}</span></div>
    <div class="susp">
      <div class="art">${art}<div class="lv">${bars}</div></div>
      <div class="info">
        <p>Compressor-fed air springs. Once fitted, the car is lowered and raised step by step from the car key.</p>
        <ul class="checks">
          ${check('Step-by-step ride height from the key')}
          ${check('Automatic camber when lowered')}
          ${check('Raises itself at high speed')}
          ${check('Nearby players see it too')}
        </ul>
        <div class="buy">
          <div><small>INSTALLATION</small><b>${money(S.cfg.air.price)}</b></div>
          <button class="fit" id="fitBtn" ${fitted ? 'disabled' : ''}>${fitted ? (needKit ? 'INSTALLED' : 'INCLUDED') : 'FIT KIT'}</button>
        </div>
      </div>
    </div>`;
}

/* --- BRAKES --- */
function discSvg(idx) {
  let slots = '';
  for (let i = 0; i < 10; i++) {
    const a = i * 36;
    slots += `<line class="slot" x1="60" y1="24" x2="60" y2="32" transform="rotate(${a} 60 60)"/>`;
  }
  return `<svg viewBox="0 0 120 100"><circle class="rot" cx="60" cy="52" r="38" transform="translate(0 0)"/>
    <g transform="translate(0 -8)">${slots}</g>
    <circle class="hub" cx="60" cy="52" r="12"/>
    <rect class="cal" x="${86 - idx * 1}" y="${30 - idx * 1.5}" width="${12 + idx * 2}" height="${30 + idx * 3}" rx="4"/></svg>`;
}

function viewBrakes() {
  const c = S.cfg;
  const cur = c.brakes[S.sel.brakes];
  const idxSel = c.brakeOrder.indexOf(S.sel.brakes);
  const cards = c.brakeOrder.map((id, idx) => {
    const b = c.brakes[id];
    const inst = (S.installed.brakes || 'stock') === id;
    const pct = Math.round((b.force - 1) * 100);
    return `<button class="stage ${S.sel.brakes === id ? 'sel' : ''}" data-brake="${id}" style="--c:${b.color}">
      <div class="tag">${esc(b.tag)}</div>
      <div class="disc">${discSvg(idx)}<div class="num">${idx}</div></div>
      <div class="ttl">${esc(b.title)}</div>
      <div class="foot">
        <div class="hpl"><span class="hp">x${b.force.toFixed(2)}<small>FORCE</small></span>${pct ? `<span class="pct">${sign(pct)}</span>` : ''}</div>
        <div class="pr">${b.price ? money(b.price) : 'FREE'}${inst ? `<span class="inst">✓ INSTALLED</span>` : ''}</div>
      </div></button>`;
  }).join('');

  const stopM = c.baseStopMeters / cur.force;
  const rows = [
    ['Braking Force', 'x' + cur.force.toFixed(2), 1, cur.force, 2.6, Math.round((cur.force - 1) * 100)],
    ['Handbrake', 'x' + cur.handbrake.toFixed(2), 1, cur.handbrake, 2.0, Math.round((cur.handbrake - 1) * 100)],
    ['100-0 km/h', stopM.toFixed(1) + ' m', c.baseStopMeters, stopM, c.baseStopMeters * 1.1, Math.round((stopM / c.baseStopMeters - 1) * 100)],
  ].map(([label, text, stock, val, max, d]) => `
    <div class="rw"><label>${label}</label>
      <div class="trk"><b style="width:${Math.min(100, val / max * 100).toFixed(1)}%"></b><u style="left:${Math.min(100, stock / max * 100).toFixed(1)}%"></u></div>
      <div class="v">${text}</div><div class="d ${d ? '' : 'z'}" style="${label === '100-0 km/h' && d < 0 ? '' : ''}">${d ? sign(d) : '—'}</div></div>`).join('');

  const abs = `<div class="toggles one"><button class="tg ${S.sel.abs ? 'on' : ''}" data-abs>
      <span class="sw"></span>
      <div class="ico">${ICON.brake}</div>
      <h4>ABS · Anti-lock Braking</h4>
      <p>Keeps the car straight under hard braking. ${money(c.abs.price)} one-time.</p>
    </button></div>`;

  return `
    <div class="head-row"><div><div class="eyebrow">BRAKE SYSTEM</div><h1 class="h1">Brake Upgrade</h1></div></div>
    <div class="stages">${cards}</div>
    <div class="detail">
      <div><div class="eyebrow">${esc(cur.label.toUpperCase())}</div><h3>${esc(cur.title)}</h3><p>${esc(cur.desc)}</p>
        <div class="legend2"><span><i class="a"></i>STOCK</span><span><i class="b"></i>SELECTED</span></div></div>
      <div class="rows">${rows}</div>
    </div>${abs}`;
}

/* --- LAUNCH --- */
function powerLabel(v) { return v < 20 ? 'SOFT' : v < 45 ? 'MEDIUM' : v < 70 ? 'FIRM' : v < 90 ? 'HARD' : 'MAX'; }
function slipLabel(v) { return v < 5 ? 'NONE' : v < 25 ? 'LIGHT' : v < 50 ? 'MEDIUM' : v < 75 ? 'HEAVY' : 'BURNOUT'; }
function launchLabel(p, s) { return `${powerLabel(p)} power · ${slipLabel(s).toLowerCase()} slip`.replace(/^./, m => m.toUpperCase()); }

function viewLaunch() {
  const presets = S.cfg.launchMenu.presets.map(p =>
    `<button class="pre ${S.sel.launchPower === p.power && S.sel.launchSlip === p.slip ? 'on' : ''}" data-preset="${p.id}">${esc(p.label.toUpperCase())}</button>`).join('');
  const card = (key, eyebrow, title, desc, val, label, ends) => `
    <div class="lc">
      <div class="top2"><div><div class="eyebrow">${eyebrow}</div><h3>${title}</h3></div>
        <div class="val"><b id="${key}Val">${val}</b><small id="${key}Lbl">${label}</small></div></div>
      <p>${desc}</p>
      <input type="range" min="0" max="100" step="1" value="${val}" id="${key}Rng" style="--p:${val}%">
      <div class="ends"><span>${ends[0]}</span><span>${ends[1]}</span></div>
    </div>`;
  return `
    <div class="eyebrow">LAUNCH CONTROL</div><h1 class="h1">Launch Setup</h1>
    <div class="presets">${presets}</div>
    <div class="lcards">
      ${card('lp', 'POWER', 'Launch Power', 'How hard the car leaves the line. Higher values send more power to the wheels from a standstill.', S.sel.launchPower, powerLabel(S.sel.launchPower), ['SOFT', 'MAX'])}
      ${card('ls', 'WHEELSPIN', 'Wheelspin', 'How much the tyres may break loose. 0 keeps the car dead straight with no wheelspin; high values allow burnouts.', S.sel.launchSlip, slipLabel(S.sel.launchSlip), ['NONE', 'BURNOUT'])}
    </div>
    <div class="note"><b>Tip:</b> For the fastest straight launch use high power and zero wheelspin. The setting is written to the car with <b>FLASH ECU</b> and applies when ESP is on; with ESP off the car also gets the full wheelspin.</div>`;
}

function turboKits() {
  const T = S.cfg.turbo;
  const items = T.order.map(id => {
    const k = T.kits[id];
    const inst = (S.installed.turbo || 'stock') === id;
    const boostW = Math.min(100, k.boost / 1.9 * 100).toFixed(0);
    const spoolW = Math.max(8, Math.min(100, (1.45 - k.spool) / 0.8 * 100)).toFixed(0);
    return `<button class="kit ${(S.sel.turbo || 'stock') === id ? 'sel' : ''}" data-turbo="${id}">
      <div class="kh"><b>${esc(k.label)}</b><span>${k.price ? money(k.price) : 'FREE'}</span></div>
      <p>${esc(k.desc)}</p>
      <div class="km"><span>BOOST</span><i><b style="width:${boostW}%"></b></i><span>SPOOL</span><i><b style="width:${spoolW}%"></b></i></div>
      ${inst ? '<em>✓ INSTALLED</em>' : ''}</button>`;
  }).join('');
  return `<div class="eyebrow kits-h">TURBO KIT</div><div class="kits">${items}</div>`;
}

function viewExhaust() {
  const icons = { flutter: ICON.flutter, smoke: ICON.smoke, valve: ICON.valve };
  const cards = S.cfg.exhaustOrder.map(k => {
    const fx = S.cfg.exhaust[k];
    return `<button class="tg ${S.sel[k] ? 'on' : ''}" data-fx="${k}">
      <span class="sw"></span>
      <div class="ico">${icons[k] || ICON.exhaust}</div>
      <h4>${esc(fx.label)}</h4><p>${esc(fx.desc)}</p>
    </button>`;
  }).join('');
  return `
    <div class="head-row"><div><div class="eyebrow">EXHAUST SYSTEM</div><h1 class="h1" style="margin-bottom:10px">Exhaust &amp; Effects</h1></div>
      <div class="ex-note">${ICON.key}<span>Exhaust effects are switched on from the car remote</span></div></div>
    ${exhaustDiagram()}
    ${turboKits()}
    <div class="toggles">${cards}</div>`;
}

/* --- DYNO --- */
function viewDyno() {
  const d = S.dyno;
  return `
    <div class="dyno-top"><div><div class="eyebrow">TEST BENCH</div><h1 class="h1" style="margin:4px 0 0">Dyno Power Test</h1></div>
      <div class="legend"><span><i style="background:var(--ac)"></i>Power (HP)</span><span><i style="background:#fff"></i>Torque (Nm)</span></div></div>
    <div class="chart"><canvas id="cv"></canvas>${d ? '' : '<div class="idle">Stop the car, start the engine and press “Run test”.</div>'}</div>
    <div class="dyno-bottom">
      <div class="dstat"><small>MAX POWER</small><b>${d ? d.maxHp + ' HP' : '—'}</b></div>
      <div class="dstat"><small>MAX TORQUE</small><b>${d ? d.maxTq + ' Nm' : '—'}</b></div>
      <div class="dstat"><small>VS STOCK</small><b class="up">${d ? (d.vsStock >= 0 ? '+' : '') + d.vsStock + ' HP' : '—'}</b></div>
      <button class="retest" id="dynoBtn" ${S.dynoRunning ? 'disabled' : ''}>${ICON.refresh}<span>${d ? 'RUN AGAIN' : 'RUN TEST'}</span></button>
    </div>
    ${runsPanel()}`;
}

function runsPanel() {
  const runs = Array.isArray(S.installed.runs) ? S.installed.runs : [];
  const last = runs[0];
  const fmt = ts => { const d = new Date(ts * 1000); return String(d.getDate()).padStart(2, '0') + '.' + String(d.getMonth() + 1).padStart(2, '0') + ' ' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); };
  const stageName = id => (S.cfg.stages[id] || { label: '' }).label;
  const rows = runs.slice(0, 5).map(r => `<div><span>${Number(r.t100).toFixed(2)} s</span><span>${esc(stageName(r.stage))}${r.rpm ? ' · ' + r.rpm + ' RPM' : ''}</span><span>${r.ts ? fmt(r.ts) : ''}</span></div>`).join('');
  return `<div class="runs">
    <div class="rbig"><small>0-100 KM/H</small><b>${last ? Number(last.t100).toFixed(2) + ' s' : '—'}</b>
      <span>${last ? (last.t60 ? '0-60: ' + Number(last.t60).toFixed(2) + ' s · ' : '') + esc(stageName(last.stage)) : 'No launch test yet'}</span></div>
    <div class="rlist"><small>LAST RUNS</small>${rows || '<span style="font-size:11px;color:var(--mute)">Start a launch test to record your 0-100 time.</span>'}</div>
    <button class="retest" data-lctest>${ICON.refresh}<span>START 0-100 TEST</span></button>
  </div>`;
}

/* ===== Interactions ===== */
function bindMain() {
  $$('[data-stage]').forEach(b => b.addEventListener('click', () => { S.sel.stage = b.dataset.stage; play('click', 0.4); render(); }));
  $$('[data-gear]').forEach(b => b.addEventListener('click', () => { S.sel.gearbox = b.dataset.gear; play('click', 0.4); render(); }));
  $$('[data-snd]').forEach(b => b.addEventListener('click', () => { S.sel.sound = b.dataset.snd; play('click', 0.4); render(); }));
  $$('[data-fx]').forEach(b => b.addEventListener('click', () => { const k = b.dataset.fx; S.sel[k] = !S.sel[k]; play('click', 0.4); render(); }));
  $$('[data-ecu]').forEach(r => r.addEventListener('input', () => {
    const k = r.dataset.ecu, v = +r.value, min = +r.min, max = +r.max;
    S.sel.ecu[k] = v;
    r.style.setProperty('--p', ((v - min) / (max - min) * 100).toFixed(1) + '%');
    updateEcuPills();
    renderSide();
  }));
  $$('[data-ecubtn]').forEach(b => b.addEventListener('click', () => {
    const [k, v] = b.dataset.ecubtn.split(':');
    S.sel.ecu[k] = v; play('click', 0.4); render();
  }));
  $$('[data-ecutoggle]').forEach(b => b.addEventListener('click', () => {
    const k = b.dataset.ecutoggle; S.sel.ecu[k] = !S.sel.ecu[k]; play('click', 0.4); render();
  }));
  const er = $('#ecuReset');
  if (er) er.addEventListener('click', () => { S.sel.ecu = { ...S.cfg.ecuTune.defaults }; play('click', 0.4); render(); });
  const ea = $('#ecuApply');
  if (ea) ea.addEventListener('click', () => $('#flashBtn').click());
  const fit = $('#fitBtn');
  if (fit) fit.addEventListener('click', async () => {
    if (S.installed.air || S.cfg.air.requireKit === false) return;
    play('click', 0.5);
    const r = await post('fitAir');
    if (r.ok) {
      S.installed = { ...S.installed, ...r.tune };
      play('done', 0.6);
      toast('Air suspension installed · ' + money(r.price) + ' paid');
      render();
    } else {
      toast(r.msg || 'Installation failed.', true);
    }
  });
  $$('[data-turbo]').forEach(b => b.addEventListener('click', () => { S.sel.turbo = b.dataset.turbo; play('click', 0.4); render(); }));
  $$('[data-lctest]').forEach(b => b.addEventListener('click', async () => {
    play('click', 0.4);
    const r = await post('launchTest');
    if (!r.ok) toast('Sit in the driver seat and stop the car to start the test.', true);
  }));
  $$('[data-brake]').forEach(b => b.addEventListener('click', () => { S.sel.brakes = b.dataset.brake; play('click', 0.4); render(); }));
  $$('[data-abs]').forEach(b => b.addEventListener('click', () => { S.sel.abs = !S.sel.abs; play('click', 0.4); render(); }));
  $$('[data-preset]').forEach(b => b.addEventListener('click', () => {
    const p = S.cfg.launchMenu.presets.find(x => x.id === b.dataset.preset);
    if (p) { S.sel.launchPower = p.power; S.sel.launchSlip = p.slip; play('click', 0.4); render(); }
  }));
  const bindRange = (id, key, labelFn) => {
    const r = $('#' + id + 'Rng');
    if (!r) return;
    r.addEventListener('input', () => {
      const v = +r.value;
      S.sel[key] = v;
      r.style.setProperty('--p', v + '%');
      $('#' + id + 'Val').textContent = v;
      $('#' + id + 'Lbl').textContent = labelFn(v);
      $$('[data-preset]').forEach(b => {
        const p = S.cfg.launchMenu.presets.find(x => x.id === b.dataset.preset);
        b.classList.toggle('on', !!p && p.power === S.sel.launchPower && p.slip === S.sel.launchSlip);
      });
      renderSide();
    });
  };
  bindRange('lp', 'launchPower', powerLabel);
  bindRange('ls', 'launchSlip', slipLabel);

  const inp = $('#sndSearch');
  if (inp) {
    inp.addEventListener('input', () => {
      S.query = inp.value;
      const pos = inp.selectionStart;
      $('#main').innerHTML = viewSound();
      bindMain();
      const n = $('#sndSearch'); n.focus(); n.setSelectionRange(pos, pos);
    });
  }

  const db = $('#dynoBtn');
  if (db) db.addEventListener('click', async () => {
    if (S.dynoRunning) return;
    play('click', 0.4);
    const r = await post('dyno');
    if (!r.ok) toast('Could not start the dyno.', true);
  });
}

/* ===== Flash: terminal + ECU kilidi (mini oyun) + yazma ===== */
$('#flashBtn').addEventListener('click', startFlash);

const sleep = ms => new Promise(r => setTimeout(r, ms));
const rb = n => Array.from({ length: n }, () => Math.floor(Math.random() * 256).toString(16).toUpperCase().padStart(2, '0')).join(' ');
const sp = (t, c) => `<span class="${c || ''}">${esc(t)}</span>`;

const Term = {
  open(title) {
    $('#termTitle').textContent = title;
    $('#termBody').innerHTML = '';
    $('#termBar').style.width = '0%';
    $('#termStatus').textContent = 'Hazırlanıyor...';
    $('#term').classList.remove('hidden');
  },
  close() { $('#term').classList.add('hidden'); },
  async line(html, wait = 110) {
    const body = $('#termBody');
    const d = document.createElement('div');
    d.className = 'l';
    d.innerHTML = html;
    body.appendChild(d);
    while (body.children.length > 17) body.removeChild(body.firstChild);
    if (wait) await sleep(wait);
  },
  bar(p, text) {
    $('#termBar').style.width = Math.max(0, Math.min(100, p)) + '%';
    if (text) $('#termStatus').textContent = text;
  },
};

async function abortFlash(msg) {
  await sleep(900);
  Term.close();
  $('#lock').classList.add('hidden');
  S.flashing = false;
  post('flashDone');
  if (msg) toast(msg, true);
  render();
}

async function startFlash() {
  if (S.flashing || !isDirty()) return;
  play('click', 0.5);
  S.flashing = true;
  renderSide();

  const st = S.sel.stage;
  const file = st === 'stock' ? 'stock.bin' : st.replace('stage', 'stage_') + '.bin';
  Term.open('ecu-flash — ' + file);
  play('beep', 0.5);
  await Term.line(sp('$ ', 'dim') + sp(`ecu-flash --target ${file} --plate ${S.plate}`, 'cmd'), 320);
  await Term.line('Connecting to ECU @ CAN 500 kbps ...', 260);
  Term.bar(2, 'ECU\'ye bağlanılıyor...');
  await Term.line(sp('[7E0] >> ', 'dim') + '10 03          DIAGNOSTIC SESSION', 160);
  await Term.line(sp('[7E8] << ', 'dim') + '50 03 00 32 01 F4   ' + sp('OK', 'ok'), 160);
  await Term.line(sp('[7E0] >> ', 'dim') + '27 01          SEED REQUEST', 160);
  await Term.line(sp('[7E8] << ', 'dim') + '67 01 ' + rb(4), 260);

  // ---- ECU kilidi ----
  const lockCfg = S.cfg.ecuLock;
  if (lockCfg && lockCfg.enabled) {
    Term.bar(6, 'Güvenlik erişimi isteniyor...');
    const begin = await post('lockBegin');
    if (!begin.ok) {
      await Term.line(sp(begin.msg || 'ECU kilitli.', 'err'), 0);
      return abortFlash(begin.msg || 'ECU kilitli.');
    }
    if (!begin.skip) {
      const len = (lockCfg.lengthByStage && lockCfg.lengthByStage[st]) || 4;
      const r = await Lock.run(lockCfg, len);
      const done = await post('lockDone', { ok: r.ok, cancelled: !!r.cancelled });
      if (!r.ok || !done.ok) {
        $('#lock').classList.add('hidden');
        await Term.line(sp('[7E8] << ', 'dim') + '7F 27 35   ' + sp('SECURITY ACCESS DENIED', 'err'), 0);
        Term.bar(6, 'Erişim reddedildi');
        return abortFlash(r.cancelled ? 'ECU erişimi iptal edildi.' : 'ECU erişimi reddedildi.');
      }
      $('#lock').classList.add('hidden');
    }
  }

  await Term.line(sp('[7E0] >> ', 'dim') + '27 02 ' + rb(4) + '   KEY', 200);
  await Term.line(sp('[7E8] << ', 'dim') + '67 02          ' + sp('SECURITY ACCESS GRANTED', 'ok'), 260);
  Term.bar(8, 'Kalibrasyon okunuyor...');
  await Term.line('Reading calibration OEM ...', 220);
  for (let i = 0; i < 8; i++) {
    const addr = '0x' + Math.floor(Math.random() * 0x0fffff).toString(16).toUpperCase().padStart(6, '0');
    await Term.line(sp('READ  ', 'dim') + addr + '  ' + rb(16), 85);
    Term.bar(8 + (i + 1) * 2, 'Kalibrasyon okunuyor...');
  }
  const bk = Math.floor(Math.random() * 0xfffffff).toString(16).padStart(8, '0');
  await Term.line(sp('Backup saved → ', 'dim') + `backup_${bk}.bin  ` + sp('OK', 'ok'), 300);

  // ---- sunucuya yaz (ücret + kayıt) ----
  Term.bar(25, 'Kalibrasyon okunuyor...');
  const res = await post('flash', S.sel);
  if (!res.ok) {
    await Term.line(sp('HATA: ' + (res.msg || 'Flash başarısız.'), 'err'), 0);
    return abortFlash(res.msg || 'Flash failed.');
  }
  await runWriting(res);
}

async function runWriting(res) {
  const dur = S.cfg.flashDuration || 9000;
  const start = Date.now();
  const phases = [[45, 'ECU belleği siliniyor...'], [85, 'Yeni harita yazılıyor...'], [100, 'Checksum doğrulanıyor...']];
  let lastLine = 0;
  while (true) {
    const t = Math.min(1, (Date.now() - start) / dur);
    const p = 25 + t * 75;
    const ph = phases.find(x => p <= x[0]) || phases[phases.length - 1];
    Term.bar(p, ph[1]);
    if (Date.now() - lastLine > 260 && t < 1) {
      lastLine = Date.now();
      const addr = '0x' + Math.floor(Math.random() * 0x0fffff).toString(16).toUpperCase().padStart(6, '0');
      if (p < 45) await Term.line(sp('ERASE ', 'pk') + addr + '  ' + sp('OK', 'ok'), 0);
      else if (p < 85) await Term.line(sp('WRITE ', 'pk') + addr + '  ' + rb(8) + '  ' + sp('OK', 'ok'), 0);
      else await Term.line(sp('CRC32 ', 'pk') + '0x' + rb(4).replace(/ /g, '') + '  ' + sp('OK', 'ok'), 0);
    }
    if (t >= 1) break;
    await sleep(60);
  }
  await Term.line(sp('Flash complete. Checksum verified.', 'ok'), 700);
  finishWriting(res);
}

function finishWriting(res) {
  S.installed = { ...S.installed, ...res.tune };
  S.sel = selFromTune(res.tune);
  Term.close();
  S.flashing = false;
  post('flashDone');
  play('done', 0.6);
  toast('ECU updated successfully' + (res.price ? ' · ' + money(res.price) + ' paid' : ''));
  render();
}

/* ===== ECU Güvenlik Anahtarı: hedef diziyi buffer'a yaz; ilk seçim en üst satırdan, sonra sütun <-> satır ===== */
const Lock = {
  active: false, _resolve: null,
  cancel() { if (this._resolve) this._finish({ ok: false, cancelled: true }); },
  _finish(r) {
    clearInterval(this._timer);
    this.active = false;
    const fn = this._resolve; this._resolve = null;
    if (fn) fn(r);
  },
  gen(n, len, codes) {
    for (let attempt = 0; attempt < 300; attempt++) {
      const grid = Array.from({ length: n }, () => Array.from({ length: n }, () => codes[Math.floor(Math.random() * codes.length)]));
      const used = new Set(), path = [];
      let r = 0, c = Math.floor(Math.random() * n);
      path.push([r, c]); used.add(r + ',' + c);
      let ok = true;
      for (let k = 1; k < len; k++) {
        const col = k % 2 === 1;                           // tek adım: aynı sütun, çift adım: aynı satır
        const opts = [];
        for (let i = 0; i < n; i++) { const nr = col ? i : r, nc = col ? c : i; if (!used.has(nr + ',' + nc)) opts.push([nr, nc]); }
        if (!opts.length) { ok = false; break; }
        [r, c] = opts[Math.floor(Math.random() * opts.length)];
        path.push([r, c]); used.add(r + ',' + c);
      }
      if (!ok) continue;
      const target = path.map(([pr, pc]) => grid[pr][pc]);
      if (new Set(target).size < 2) continue;
      return { grid, target };
    }
    return null;
  },
  run(cfg, len) {
    return new Promise(resolve => {
      this._resolve = resolve;
      this.active = true;
      const n = cfg.grid || 5, cap = cfg.buffer || 6, total = (cfg.time || 15) * 1000;
      const pz = this.gen(n, len, cfg.codes || ['55', 'E9', 'FF', '1C', 'BD', '7A']);
      const el = $('#lock');
      const buffer = [], used = new Set();
      let mode = { type: 'row', idx: 0 };
      const t0 = Date.now();

      el.innerHTML = `<div class="lk" id="lk">
        <div class="wrap">
          <div class="eb">GÜVENLİK ADIMI</div>
          <h2>ECU Güvenlik Anahtarı</h2>
          <div class="ds">Hedef diziyi buffer'a yaz. İlk seçim <b>en üst satırdan</b>, sonra sırayla <b>sütun ⇔ satır</b>.</div>
          <div class="lktop">
            <div class="panel"><small>SÜRE</small><div class="time" id="lkTime">0.0</div><div class="tb2"><i id="lkBar"></i></div></div>
            <div class="panel"><small>BUFFER</small><div class="slots" id="lkSlots"></div></div>
          </div>
          <div class="mid">
            <div class="grid" id="lkGrid"></div>
            <div class="tgt"><small>HEDEF DİZİ</small><div class="tl" id="lkTgt"></div><div class="lkhint" id="lkHint"></div></div>
          </div>
        </div>
        <div class="res" id="lkRes"></div>
      </div>`;
      el.classList.remove('hidden');

      $('#lkTgt').innerHTML = pz.target.map(t => `<div class="t">${t}</div>`).join('');
      $('#lkSlots').innerHTML = Array.from({ length: cap }, () => '<div class="slot"></div>').join('');

      const validCells = m => {
        const out = [];
        for (let i = 0; i < n; i++) {
          const r = m.type === 'row' ? m.idx : i, c = m.type === 'row' ? i : m.idx;
          if (!used.has(r + ',' + c)) out.push([r, c]);
        }
        return out;
      };
      const matched = () => {
        for (let k = Math.min(len, buffer.length); k >= 1; k--) {
          let ok = true;
          for (let j = 0; j < k; j++) if (buffer[buffer.length - k + j] !== pz.target[j]) { ok = false; break; }
          if (ok) return k;
        }
        return 0;
      };
      const draw = () => {
        const vs = new Set(validCells(mode).map(([r, c]) => r + ',' + c));
        const g = $('#lkGrid');
        g.innerHTML = '';
        for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) {
          const b = document.createElement('button');
          const key = r + ',' + c;
          b.className = 'cell' + (vs.has(key) ? ' v' : '') + (used.has(key) ? ' u' : '');
          b.textContent = pz.grid[r][c];
          if (vs.has(key)) b.addEventListener('click', () => pick(r, c));
          g.appendChild(b);
        }
        $$('#lkSlots .slot').forEach((sl, i) => { sl.textContent = buffer[i] || ''; sl.classList.toggle('f', i < buffer.length); });
        const m = matched();
        $$('#lkTgt .t').forEach((t, i) => t.classList.toggle('m', i < m));
        $('#lkHint').innerHTML = `Şimdi <b>${mode.idx + 1}. ${mode.type === 'row' ? 'satırdan' : 'sütundan'}</b> seç.`;
      };
      const end = (ok, reason) => {
        const box = $('#lk');
        box.classList.add('done');
        const res = $('#lkRes');
        res.className = 'res ' + (ok ? 'ok' : 'bad');
        res.innerHTML = ok
          ? `<svg viewBox="0 0 24 24"><rect x="5" y="11" width="14" height="9" rx="2" fill="currentColor" fill-opacity=".25"/><path d="M8 11V8a4 4 0 0 1 7.5-2"/></svg><b>ERİŞİM İZNİ VERİLDİ</b>`
          : `<svg viewBox="0 0 24 24"><rect x="5" y="11" width="14" height="9" rx="2" fill="currentColor" fill-opacity=".25"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg><b>ERİŞİM REDDEDİLDİ</b><span>${esc(reason || '')}</span>`;
        play(ok ? 'done' : 'beep', 0.6);
        setTimeout(() => this._finish({ ok }), ok ? 1300 : 1500);
      };
      const pick = (r, c) => {
        if (!this.active) return;
        play('click', 0.35);
        buffer.push(pz.grid[r][c]);
        used.add(r + ',' + c);
        mode = mode.type === 'row' ? { type: 'col', idx: c } : { type: 'row', idx: r };
        draw();
        if (matched() >= len) { this.active = false; clearInterval(this._timer); return end(true); }
        if (buffer.length >= cap) { this.active = false; clearInterval(this._timer); return end(false, 'Buffer doldu.'); }
        if (!validCells(mode).length) { this.active = false; clearInterval(this._timer); return end(false, 'Hamle kalmadı.'); }
      };

      draw();
      this._timer = setInterval(() => {
        if (!this.active) return;
        const left = Math.max(0, total - (Date.now() - t0));
        $('#lkTime').textContent = (left / 1000).toFixed(1);
        $('#lkBar').style.width = (left / total * 100) + '%';
        if (left <= 0) { this.active = false; clearInterval(this._timer); end(false, 'Süre doldu.'); }
      }, 50);
    });
  },
};

function toast(msg, err) {
  const t = $('#toast');
  t.textContent = msg;
  t.className = 'toast' + (err ? ' err' : '');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.add('hidden'), 3200);
}

/* ===== Dyno chart ===== */
function startDyno(d) {
  S.dyno = d; S.dynoRunning = true;
  if (S.tab !== 'dyno') {
    S.tab = 'dyno';
    $$('#tabs button').forEach(x => x.classList.toggle('on', x.dataset.tab === 'dyno'));
  }
  render();
  play('beep', 0.5);
  const start = Date.now();
  clearInterval(S.dynoTimer);
  S.dynoTimer = setInterval(() => {
    const t = Math.min(1, (Date.now() - start) / d.duration);
    drawChart(t);
    if (t >= 1) clearInterval(S.dynoTimer);
  }, 40);
}

function endDyno() {
  S.dynoRunning = false;
  clearInterval(S.dynoTimer);
  if (S.tab === 'dyno') render();
  play('done', 0.5);
}

function drawChart(progress) {
  const cv = $('#cv');
  if (!cv) return;
  const rect = cv.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  cv.width = Math.max(10, rect.width * dpr);
  cv.height = Math.max(10, rect.height * dpr);
  const g = cv.getContext('2d');
  g.scale(dpr, dpr);
  const W = rect.width, H = rect.height;
  const padL = 46, padR = 16, padT = 16, padB = 28;
  const ac = getComputedStyle(document.documentElement).getPropertyValue('--ac').trim() || '#ff4d6d';
  g.clearRect(0, 0, W, H);

  g.strokeStyle = 'rgba(255,255,255,.06)'; g.lineWidth = 1;
  for (let i = 0; i <= 6; i++) {
    const x = padL + (W - padL - padR) * i / 6;
    g.beginPath(); g.moveTo(x, padT); g.lineTo(x, H - padB); g.stroke();
    g.fillStyle = '#7d7d8c'; g.font = '11px sans-serif'; g.textAlign = 'center';
    g.fillText(String(i + 1), x, H - 9);
  }
  for (let i = 0; i <= 4; i++) {
    const y = padT + (H - padT - padB) * i / 4;
    g.beginPath(); g.moveTo(padL, y); g.lineTo(W - padR, y); g.stroke();
  }
  g.fillStyle = '#7d7d8c'; g.textAlign = 'right'; g.fillText('RPM x1000', W - padR, H - 9);

  const d = S.dyno;
  if (!d) return;

  const maxHp = Math.max(...d.hp) * 1.1;
  const maxTq = Math.max(...d.tq) * 1.1;
  const n = d.hp.length;
  const upto = Math.max(2, Math.floor(n * progress));
  const X = i => padL + (W - padL - padR) * i / (n - 1);
  const Y = (v, m) => padT + (H - padT - padB) * (1 - v / m);

  g.beginPath();
  g.moveTo(X(0), H - padB);
  for (let i = 0; i < upto; i++) g.lineTo(X(i), Y(d.hp[i], maxHp));
  g.lineTo(X(upto - 1), H - padB); g.closePath();
  const grad = g.createLinearGradient(0, padT, 0, H - padB);
  grad.addColorStop(0, ac + '66'); grad.addColorStop(1, ac + '00');
  g.fillStyle = grad; g.fill();

  const line = (arr, m, color) => {
    g.beginPath();
    for (let i = 0; i < upto; i++) { const x = X(i), y = Y(arr[i], m); i ? g.lineTo(x, y) : g.moveTo(x, y); }
    g.strokeStyle = color; g.lineWidth = 3; g.lineJoin = 'round'; g.stroke();
  };
  line(d.hp, maxHp, ac);
  line(d.tq, maxTq, '#ffffff');
}
window.addEventListener('resize', () => { if (S.tab === 'dyno') drawChart(S.dyno ? 1 : 0); });

/* ===================== CAR REMOTE ===================== */
const F = { tune: null, modes: null, busy: false };

function openFob(d) {
  airHoldStop();
  F.tune = { ...d.tune }; F.modes = d.modes; F.air = d.air;
  $('#fobPlate').textContent = d.plate || '';
  document.documentElement.style.setProperty('--ac', '#e8e8ee');
  $('#tablet').classList.add('hidden');
  $('#fob').classList.remove('hidden');
  $('#fobToast').classList.add('hidden');
  renderFob();
  play('beep', 0.4);
}

// Kumanda ikonları (referanstaki dolu beyaz ikonlar)
const CAR_BODY = '<path d="M5.2 11 6.8 6.9A2 2 0 0 1 8.7 5.6h6.6a2 2 0 0 1 1.9 1.3L18.8 11c1.2.4 2.2 1.4 2.2 2.8V17a1 1 0 0 1-1 1h-1.3a1.9 1.9 0 0 1-3.8 0h-5.8a1.9 1.9 0 0 1-3.8 0H4a1 1 0 0 1-1-1v-3.2c0-1.4 1-2.4 2.2-2.8z"/><path d="M8 7.6h8l1 2.6H7z" fill="#101014"/><circle cx="7" cy="14" r="1.1" fill="#101014"/><circle cx="17" cy="14" r="1.1" fill="#101014"/>';
function flagSvg() {
  let sq = '';
  for (let r = 0; r < 3; r++) for (let c = 0; c < 4; c++) if ((r + c) % 2) sq += `<rect x="${6 + c * 3.2}" y="${4 + r * 3.2}" width="3.2" height="3.2" fill="#101014"/>`;
  return `<svg viewBox="0 0 24 24"><rect x="4.4" y="3" width="1.8" height="18" rx=".9"/><rect x="6" y="4" width="12.8" height="9.6"/>${sq}</svg>`;
}
const FOB = {
  eco: '<svg viewBox="0 0 24 24"><path d="M3.5 20.5C3.5 11 9 4.5 20.5 4c0 10-5.5 16.4-13.5 15.5 1-4.6 3.7-7.6 8.3-9.6-5 1-9.4 4.4-11.8 10.6z"/></svg>',
  normal: `<svg viewBox="0 0 24 24">${CAR_BODY}</svg>`,
  sport: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9.5"/><path d="M12 12.4l3.8-4.6" stroke="#101014" stroke-width="2" stroke-linecap="round" fill="none"/><g fill="#101014"><circle cx="6.8" cy="13.6" r=".95"/><circle cx="8.2" cy="9" r=".95"/><circle cx="12" cy="6.6" r=".95"/><circle cx="17.2" cy="13.6" r=".95"/></g></svg>',
  sportp: flagSvg(),
  esp: `<svg viewBox="0 0 24 24"><g transform="translate(3.6 -1.2) scale(.82)">${CAR_BODY}</g><path d="M4.5 20.6c1.4-1.1 2.5 1.1 4 0s2.5 1.1 4 0 2.5 1.1 4 0 2.5 1.1 3.8 0" stroke="currentColor" stroke-width="1.7" fill="none" stroke-linecap="round"/></svg>`,
  down: '<svg viewBox="0 0 24 24"><path d="m5.5 9 6.5 6.5L18.5 9"/></svg>',
  up: '<svg viewBox="0 0 24 24"><path d="m5.5 15 6.5-6.5L18.5 15"/></svg>',
  exhaust: '<svg viewBox="0 0 24 24"><path d="M8 3.5v3M12 3.5v3M16 3.5v3"/><path d="M12 15.2c-1.9-3-5.6-3.6-7.2-1.5-1.5 2 0 5 2.7 5 2.8 0 4.5-2.3 4.5-3.5zm0 0c1.9-3 5.6-3.6 7.2-1.5 1.5 2 0 5-2.7 5-2.8 0-4.5-2.3-4.5-3.5z"/></svg>',
};

function renderFob() {
  const t = F.tune;
  const lv = (F.air && F.air.levels) || 5, cur = t.airLevel || lv;
  const airOk = t.air || (F.air && F.air.requireKit === false);
  const lvs = Array.from({ length: lv }, (_, i) => `<i class="${airOk && i < cur ? 'on' : ''}"></i>`).join('');
  const mk = (id, label) => `<button class="kb ${t.mode === id ? 'on' : ''}" data-mode="${id}">${FOB[id]}${label}</button>`;
  $('#fobPad').innerHTML =
    mk('eco', 'ECO') + mk('normal', 'COMFORT') + mk('sport', 'SPORT') + mk('sportp', 'SPORT+') +
    `<button class="kb wide ${t.esp === false ? 'on' : ''}" data-esp="1">${FOB.esp}ESP OFF</button>` +
    `<div class="air ${airOk ? '' : 'off'}"><button data-air="-1" aria-label="Lower">${FOB.down}</button>
       <div class="mid">AIR<div class="lvs">${lvs}</div></div><button data-air="1" aria-label="Raise">${FOB.up}</button></div>` +
    `<button class="kb wide red ${t.valve ? 'on' : ''}" data-valve="1">${FOB.exhaust}EXHAUST</button>`;

}

async function fobSet(field, value) {
  if (F.busy && Date.now() - (F.busyAt || 0) < 4000) return null;   // takılı kalırsa 4 sn sonra serbest
  F.busy = true; F.busyAt = Date.now();
  play('click', 0.5);
  let r = {};
  try { r = await post('fobSet', { field, value }); } finally { F.busy = false; }
  if (r.ok) { F.tune = r.tune; renderFob(); return r.tune; }
  if (r.msg) fobToast(field === 'airLevel' ? 'AIR SUSPENSION' : 'EXHAUST', r.msg);
  return null;
}

async function fobMode(id) {
  const t = await fobSet('mode', id);
  if (t) fobToast('DRIVE MODE', F.modes[id].label);
}
async function fobEsp() {
  const t = await fobSet('esp', F.tune.esp === false);   // kapalıysa aç, açıksa kapat
  if (t) fobToast('ESP', t.esp === false ? 'Off · traction assist disabled' : 'On');
}
async function fobAir(step) {
  const lv = (F.air && F.air.levels) || 5;
  if (!F.tune.air && F.air && F.air.requireKit !== false) { fobToast('AIR SUSPENSION', 'Not fitted · buy the kit in the tablet'); return; }
  const cur = F.tune.airLevel || lv;
  const next = Math.max(1, Math.min(lv, cur + step));
  if (next === cur) { fobToast('AIR SUSPENSION', `Level ${cur} / ${lv}`); return; }
  const t = await fobSet('airLevel', next);
  if (t) {
    play(next < cur ? 'hiss' : 'comp', 0.5);
    fobToast('AIR SUSPENSION', `Level ${t.airLevel} / ${lv}`);
  }
}
async function fobValve() {
  const t = await fobSet('valve', !F.tune.valve);
  if (t) {
    fobToast('EXHAUST', t.valve ? 'Open · exhaust effects active' : 'Closed · stock exhaust');
    if (t.valve) play('pop', 0.5);
  }
}
// Olaylar #fobPad üzerinde bir kez (delegasyon) bağlanır: pad yeniden çizilse de tutma/bırakma kaybolmaz
let airHold = { t1: null, t2: null };
function airHoldStop() { clearTimeout(airHold.t1); clearInterval(airHold.t2); airHold.t1 = airHold.t2 = null; }
document.addEventListener('mouseup', airHoldStop);
window.addEventListener('blur', airHoldStop);
$('#fobPad').addEventListener('mousedown', e => {
  const b = e.target.closest('[data-air]');
  if (!b) return;
  const step = +b.dataset.air;
  airHoldStop();
  fobAir(step);
  airHold.t1 = setTimeout(() => { airHold.t2 = setInterval(() => fobAir(step), 1600); }, 700);
});
$('#fobPad').addEventListener('click', e => {
  const m = e.target.closest('[data-mode]');
  if (m) return fobMode(m.dataset.mode);
  if (e.target.closest('[data-esp]')) return fobEsp();
  if (e.target.closest('[data-valve]')) return fobValve();
});

function fobKey(e) {
  if (e.repeat) return;
  if (e.key === 'Escape') { post('close'); return; }
  const map = { '1': () => fobMode('eco'), '2': () => fobMode('normal'), '3': () => fobMode('sport'), '4': () => fobMode('sportp'),
    '5': fobEsp, '6': fobValve, '7': () => fobAir(-1), '8': () => fobAir(1) };
  if (map[e.key]) map[e.key]();
}

$('#fobClose').addEventListener('click', () => post('close'));

function fobToast(title, text) {
  const t = $('#fobToast');
  $('b', t).textContent = title;
  $('span', t).textContent = text;
  t.classList.remove('hidden');
  clearTimeout(fobToast._t);
  fobToast._t = setTimeout(() => t.classList.add('hidden'), 2600);
}


/* ===================== TURBO SESİ (basınca bağlı, sürücü duyar) =====================
   Oyunun kendi turbo sesi (native) yoksa Lua basınç/devir verisini gönderir ve burada sürekli bir turbo sesi üretilir:
   ıslık basınçla yükselir, gürültü katmanı hava akışını verir, gaz kapanınca blow-off çalar.
   web/sounds/turbo_loop.ogg ve blowoff_real.ogg koyarsan gerçek kayıt otomatik kullanılır. */
const Turbo = {
  ctx: null,
  init() {
    if (this.ctx) return;
    try { this.ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { return; }
    const c = this.ctx;
    this.master = c.createGain(); this.master.gain.value = 0.9; this.master.connect(c.destination);

    const len = c.sampleRate * 2, nb = c.createBuffer(1, len, c.sampleRate), d = nb.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    this.noiseBuf = nb;

    const mk = (type) => { const o = c.createOscillator(); o.type = type; const g = c.createGain(); g.gain.value = 0; o.connect(g); g.connect(this.master); o.start(); return { o, g }; };
    this.w1 = mk('sine'); this.w2 = mk('triangle'); this.w3 = mk('sine');

    this.noise = c.createBufferSource(); this.noise.buffer = nb; this.noise.loop = true;
    this.bp = c.createBiquadFilter(); this.bp.type = 'bandpass'; this.bp.Q.value = 5;
    this.gN = c.createGain(); this.gN.gain.value = 0;
    this.noise.connect(this.bp); this.bp.connect(this.gN); this.gN.connect(this.master);
    this.noise.start();

    this.tryLoad();
  },
  async load(name) {
    try {
      const r = await fetch('sounds/' + name);
      if (!r.ok) return null;
      return await this.ctx.decodeAudioData(await r.arrayBuffer());
    } catch (e) { return null; }
  },
  async tryLoad() {
    this.loopBuf = await this.load('turbo_loop.ogg');
    this.blowBuf = await this.load('blowoff_real.ogg');
    if (this.loopBuf) {
      this.loopSrc = this.ctx.createBufferSource(); this.loopSrc.buffer = this.loopBuf; this.loopSrc.loop = true;
      this.loopGain = this.ctx.createGain(); this.loopGain.gain.value = 0;
      this.loopSrc.connect(this.loopGain); this.loopGain.connect(this.master); this.loopSrc.start();
    }
  },
  update(d) {
    if (!d || !d.on) { this.fade(); return; }
    this.init();
    if (!this.ctx) return;
    const c = this.ctx, t = c.currentTime, k = 0.06;
    if (c.state === 'suspended') c.resume();
    const b = Math.max(0, Math.min(1, d.boost || 0));
    const f = (900 + b * 3300 + (d.rpm || 0) * 700) * (d.pitch || 1);
    const vol = Math.pow(b, 1.5) * 0.2 * (d.whine || 1);

    if (this.loopGain) {                                   // gerçek kayıt: ses yüksekliği ve perde basınçla
      this.loopSrc.playbackRate.setTargetAtTime(0.7 + b * 1.1 * (d.pitch || 1), t, k);
      this.loopGain.gain.setTargetAtTime(Math.pow(b, 1.2) * 0.8 * (d.whine || 1), t, k);
      this.w1.g.gain.setTargetAtTime(0, t, k); this.w2.g.gain.setTargetAtTime(0, t, k); this.w3.g.gain.setTargetAtTime(0, t, k);
      this.gN.gain.setTargetAtTime(0, t, k);
      return;
    }
    this.w1.o.frequency.setTargetAtTime(f, t, k);
    this.w2.o.frequency.setTargetAtTime(f * 1.012, t, k);
    this.w3.o.frequency.setTargetAtTime(f * 1.5, t, k);
    this.w1.g.gain.setTargetAtTime(vol, t, k);
    this.w2.g.gain.setTargetAtTime(vol * 0.5, t, k);
    this.w3.g.gain.setTargetAtTime(d.twin ? vol * 0.45 : 0, t, k);
    this.bp.frequency.setTargetAtTime(f * 0.7 + 400, t, k);
    this.gN.gain.setTargetAtTime(Math.pow(b, 1.2) * 0.09, t, k);
  },
  fade() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    [this.w1, this.w2, this.w3].forEach(w => w.g.gain.setTargetAtTime(0, t, 0.12));
    this.gN.gain.setTargetAtTime(0, t, 0.12);
    if (this.loopGain) this.loopGain.gain.setTargetAtTime(0, t, 0.12);
  },
  blow(d) {
    this.init();
    if (!this.ctx) return;
    const c = this.ctx, t = c.currentTime;
    if (c.state === 'suspended') c.resume();
    const lvl = Math.max(0.2, Math.min(1, (d && d.boost) || 0.6));
    const play = (buf, gain, delay, hpStart) => {
      const s = c.createBufferSource(); s.buffer = buf; s.loop = false;
      const g = c.createGain(); const t0 = t + (delay || 0);
      if (this.blowBuf && buf === this.blowBuf) {
        g.gain.setValueAtTime(gain, t0); s.connect(g); g.connect(this.master); s.start(t0);
        return;
      }
      const hp = c.createBiquadFilter(); hp.type = 'highpass';
      hp.frequency.setValueAtTime(hpStart, t0); hp.frequency.exponentialRampToValueAtTime(900, t0 + 0.55);
      g.gain.setValueAtTime(0.0001, t0); g.gain.linearRampToValueAtTime(gain, t0 + 0.015); g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.6);
      s.connect(hp); hp.connect(g); g.connect(this.master); s.start(t0); s.stop(t0 + 0.7);
    };
    if (this.blowBuf) { play(this.blowBuf, 0.8 * lvl, 0); return; }
    play(this.noiseBuf, 0.5 * lvl, 0, 2200 * ((d && d.pitch) || 1));
    if (d && d.twin) play(this.noiseBuf, 0.3 * lvl, 0.07, 3000);
  },
};

/* ===================== HUD: 0-100 LAUNCH TESTİ ===================== */
function showLaunchHud(d) {
  const el = $('#launchHud');
  if (!d || d.state === 'off') { el.classList.add('hidden'); return; }
  el.className = 'lh ' + d.state;
  const label = { armed: 'ARMED', holding: 'LAUNCH RPM', ready: 'GO', running: '0-100 KM/H', done: 'RESULT' }[d.state] || '';
  $('#lhSub').textContent = label;
  $('#lhText').textContent = d.text || '';
  let hint = d.sub || '';
  let pct = 0;
  if (d.state === 'holding' || d.state === 'ready') {
    pct = Math.min(100, (d.now || 0) / (d.rpm || 1) * 100);
    hint = `${hint} · ${d.now || 0} / ${d.rpm || 0} RPM`;
  } else if (d.state === 'running') {
    pct = Math.min(100, (d.kmh || 0));
  } else if (d.state === 'done') {
    pct = 100;
    if (d.t60) hint = `${hint} · 0-60: ${Number(d.t60).toFixed(2)} s`;
  } else if (d.state === 'armed') {
    hint = `${hint} · target ${d.rpm || 0} RPM · BACKSPACE cancels`;
  }
  $('#lhHint').textContent = hint;
  $('#lhBar').style.width = pct + '%';
}
