-- Dyno testi: yüklü ECU yazılımının gerçek HP / Nm değerlerini ölçer

local POINTS = 48

local function bell(x, center, width)
    local d = (x - center) / width
    return math.exp(-(d * d))
end

local function buildCurve(stockHP, tune)
    local stage = Config.Stages[tune.stage] or Config.Stages.stock
    local mode = Config.Modes[tune.mode] or Config.Modes.normal
    local turbo = stage.turbo and stage.turbo.enabled

    local targetHP = stockHP * (1.0 + stage.powerPct / 100.0) * (1.0 + mode.power * 0.01)
    local rpm, hp, tq = {}, {}, {}
    local shape = {}
    local peakShape = 0.0

    for i = 1, POINTS do
        local x = (i - 1) / (POINTS - 1)                      -- 0..1  (1000 - 7000 rpm)
        local t = 0.55 + 0.45 * bell(x, Config.Dyno.peakRpm, 0.35)
        if turbo then
            t = t + (stage.turbo.boost / 1.3) * 0.22 * bell(x, 0.28, 0.20)  -- erken turbo torku
        end
        local rpmVal = 1000 + x * 6000
        rpm[i] = math.floor(rpmVal)
        shape[i] = t * rpmVal
        if shape[i] > peakShape then peakShape = shape[i] end
    end

    local rawTq, rawMax, maxHp = {}, 0.0, 0.0
    for i = 1, POINTS do
        hp[i] = (shape[i] / peakShape) * targetHP
        rawTq[i] = hp[i] * 7121.0 / rpm[i]
        if rawTq[i] > rawMax then rawMax = rawTq[i] end
        if hp[i] > maxHp then maxHp = hp[i] end
    end
    -- Tork eğrisini tablodaki Nm/HP oranına göre ölçekle
    local k = (maxHp * Config.Dyno.torquePerHp) / rawMax
    local maxTq = 0.0
    for i = 1, POINTS do
        tq[i] = rawTq[i] * k
        if tq[i] > maxTq then maxTq = tq[i] end
        hp[i] = math.floor(hp[i] * 10) / 10
        tq[i] = math.floor(tq[i] * 10) / 10
    end

    return {
        rpm = rpm, hp = hp, tq = tq,
        maxHp = math.floor(maxHp), maxTq = math.floor(maxTq),
        vsStock = math.floor(maxHp - stockHP),
    }
end

function Abyss.RunDyno()
    local ped = PlayerPedId()
    local veh = Abyss.veh
    if veh == 0 or not DoesEntityExist(veh) or GetVehiclePedIsIn(ped, false) ~= veh then
        lib.notify({ type = 'error', description = 'Dyno için aracın içinde olmalısın.' })
        return false
    end
    if GetEntitySpeed(veh) > 1.0 then
        lib.notify({ type = 'error', description = 'Dyno için aracı durdur.' })
        return false
    end
    if not GetIsVehicleEngineRunning(veh) then
        lib.notify({ type = 'error', description = 'Motoru çalıştırman gerekiyor.' })
        return false
    end

    local mass = GetVehicleHandlingFloat(veh, 'CHandlingData', 'fMass')
    local force = GetVehicleHandlingFloat(veh, 'CHandlingData', 'fInitialDriveForce')
    local origForce = force
    -- Yüklü tune handling'i değiştirdiği için stock gücü tahmin ederken stage çarpanını geri al
    local tune = Abyss.tune or { stage = 'stock', mode = 'normal' }
    local stage = Config.Stages[tune.stage] or Config.Stages.stock
    local mode = Config.Modes[tune.mode] or Config.Modes.normal
    local divisor = stage.driveForce * (1.0 + mode.power * 0.012)
    if divisor > 0 then origForce = force / divisor end

    local stockHP = math.max(40, math.floor(origForce * mass * Config.Dyno.hpScale))
    local result = buildCurve(stockHP, tune)
    result.stockHP = stockHP
    result.duration = Config.Dyno.duration

    Abyss.Send('dynoStart', result)

    -- Aracı sabitle ve devir taraması yap
    CreateThread(function()
        FreezeEntityPosition(veh, true)
        SetVehicleHandbrake(veh, true)
        local started = GetGameTimer()
        local dur = Config.Dyno.duration
        while true do
            local t = (GetGameTimer() - started) / dur
            if t >= 1.0 then break end
            if GetVehiclePedIsIn(PlayerPedId(), false) ~= veh then break end
            -- 0 -> 0.8 yükselir, sonra düşer
            local r
            if t < 0.8 then r = 0.2 + (t / 0.8) * 0.8 else r = 1.0 - ((t - 0.8) / 0.2) * 0.65 end
            SetVehicleCurrentRpm(veh, r)
            SetControlNormal(0, 71, 1.0)
            Wait(0)
        end
        SetVehicleHandbrake(veh, false)
        FreezeEntityPosition(veh, false)
        Abyss.Send('dynoEnd', {})
    end)

    return true
end
