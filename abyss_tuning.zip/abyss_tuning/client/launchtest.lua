-- Launch Control 0-100 testi: tabletten başlatılır, ekranda yönlendirir, sonuç dyno sekmesinde görünür

local test = nil   -- { state, rpm, startedAt, t0, t60, veh, plate }

local function hud(state, text, sub, extra)
    local d = { state = state, text = text, sub = sub }
    if extra then for k, v in pairs(extra) do d[k] = v end end
    Abyss.Send('launchHud', d)
end

local function finish()
    Abyss.lcTestRpm = nil
    test = nil
end

function Abyss.StartLaunchTest()
    if test then return true end
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 or GetPedInVehicleSeat(veh, -1) ~= ped then
        lib.notify({ type = 'error', description = 'Testi başlatmak için sürücü koltuğunda olmalısın.' })
        return false
    end
    if GetEntitySpeed(veh) > 2.0 then
        lib.notify({ type = 'error', description = 'Önce aracı durdur.' })
        return false
    end

    local tune = Abyss.active[veh] or Abyss.tune or {}
    local E = Config.EcuTune
    local ecu = tune.ecu or E.defaults
    local rpm = ((ecu.lcRpm or E.defaults.lcRpm) > E.lc.min) and ecu.lcRpm or E.lc.testRpm

    Abyss.Close()                                  -- tableti kapat, sürüşe dön
    test = { state = 'armed', rpm = rpm, startedAt = GetGameTimer(), veh = veh, plate = Abyss.GetPlate(veh) }
    Abyss.lcTestRpm = rpm
    hud('armed', 'LAUNCH CONTROL', 'Hold BRAKE and press THROTTLE', { rpm = rpm, now = 0 })
    return true
end

CreateThread(function()
    while true do
        if not test then
            Wait(300)
        else
            Wait(0)
            local ped = PlayerPedId()
            local veh = test.veh
            local now = GetGameTimer()
            local LT = Config.LaunchTest

            -- iptal: araçtan inme, BACKSPACE, zaman aşımı
            if not DoesEntityExist(veh) or GetVehiclePedIsIn(ped, false) ~= veh or IsControlJustPressed(0, 177)
                or now - test.startedAt > LT.timeout then
                hud('off')
                lib.notify({ type = 'inform', description = '0-100 testi iptal edildi.' })
                finish()
            else
                local speed = GetEntitySpeed(veh)
                local kmh = speed * 3.6
                local throttle = GetControlNormal(0, 71)
                local brake = GetControlNormal(0, 72)
                local redline = Config.EcuTune.redlineRpm
                local target = test.rpm / redline
                local rpmNow = GetVehicleCurrentRpm(veh)

                if test.state == 'armed' then
                    if speed < 1.5 and throttle > 0.9 and brake > 0.5 then
                        test.state = 'holding'
                    end
                elseif test.state == 'holding' then
                    if throttle < 0.5 or brake < 0.3 then
                        test.state = 'armed'
                        hud('armed', 'LAUNCH CONTROL', 'Hold BRAKE and press THROTTLE', { rpm = test.rpm, now = 0 })
                    elseif Abyss.lcArmed and rpmNow >= target * 0.96 then
                        test.state = 'ready'
                        Abyss.PlaySound('beep', 0.5)
                        hud('ready', 'READY', 'RELEASE THE BRAKE!', { rpm = test.rpm, now = test.rpm })
                    else
                        hud('holding', 'BUILDING RPM', 'Hold BRAKE + THROTTLE', { rpm = test.rpm, now = math.floor(rpmNow * redline) })
                    end
                elseif test.state == 'ready' then
                    if brake < 0.2 and speed > 0.6 then
                        test.state = 'running'
                        test.t0 = now
                        test.t60 = nil
                    elseif throttle < 0.5 then
                        test.state = 'armed'
                        hud('armed', 'LAUNCH CONTROL', 'Hold BRAKE and press THROTTLE', { rpm = test.rpm, now = 0 })
                    end
                elseif test.state == 'running' then
                    local t = (now - test.t0) / 1000.0
                    if not test.t60 and kmh >= LT.speed60 then test.t60 = t end
                    if kmh >= LT.speed100 then
                        local run = { t100 = t, t60 = test.t60, rpm = test.rpm }
                        local plate = test.plate
                        Abyss.PlaySound('done', 0.6)
                        hud('done', ('%.2f s'):format(t), '0-100 km/h', { t60 = test.t60 })
                        finish()
                        lib.callback.await('abyss_tuning:saveRun', false, plate, run)
                        SetTimeout(LT.hudMs, function() if not test then hud('off') end end)
                    elseif t > 40.0 or (speed < 1.0 and t > 3.0) then
                        hud('off')
                        lib.notify({ type = 'error', description = '0-100 testi başarısız.' })
                        finish()
                    else
                        hud('running', ('%.2f s'):format(t), ('%d km/h'):format(math.floor(kmh)), { kmh = kmh })
                    end
                end
            end
        end
    end
end)
