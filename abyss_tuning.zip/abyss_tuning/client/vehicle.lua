-- Araç üzerinde stage / şanzıman / sürüş modu / ESP / motor sesi uygulaması

local FLOATS = {
    'fInitialDriveForce',
    'fInitialDriveMaxFlatVel',
    'fClutchChangeRateScaleUpShift',
    'fClutchChangeRateScaleDownShift',
    'fDriveInertia',
    'fInitialDragCoeff',
    'fTractionLossMult',
    'fLowSpeedTractionLossMult',
    'fTractionCurveMax',
    'fTractionCurveMin',
    'fDriveBiasFront',
    'fBrakeForce',
    'fHandBrakeForce',
    'fSuspensionRaise',
}

local limiterApplied = {}   -- [entity] = true (hız limitörü bizim tarafımızdan konduysa)
local originals = {}   -- [entity] = { float = value, audio = 'adder' }
Abyss.active = {}      -- [entity] = tune (efekt döngüleri okur)
Abyss.boost = 0.0      -- 0..1 turbo basıncı (effects.lua günceller)
Abyss.heat = 0.0

local function getOriginals(veh)
    local o = originals[veh]
    if o then return o end
    o = {}
    for _, f in ipairs(FLOATS) do
        o[f] = GetVehicleHandlingFloat(veh, 'CHandlingData', f)
    end
    local name = GetDisplayNameFromVehicleModel(GetEntityModel(veh))
    o.audio = name and name:lower() or nil
    o.suspMod = GetVehicleMod(veh, 15)
    originals[veh] = o
    return o
end

local function setF(veh, field, value)
    SetVehicleHandlingFloat(veh, 'CHandlingData', field, value + 0.0)
end

-- ===== Turbo parametreleri (stage + takılı turbo kiti) =====
function Abyss.TurboParams(tune)
    local stage = Config.Stages[tune.stage] or Config.Stages.stock
    local kitId = tune.turbo or 'stock'
    local kit = Config.Turbo.kits[kitId] or Config.Turbo.kits.stock
    local base = stage.turbo
    if kitId ~= 'stock' then
        local b = (base and base.enabled) and base or Config.Turbo.baseNoStage
        return { enabled = true, boost = b.boost * kit.boost, spool = b.spool * kit.spool, kit = kit, kitId = kitId }
    end
    if base and base.enabled then
        return { enabled = true, boost = base.boost, spool = base.spool, kit = kit, kitId = kitId }
    end
    return { enabled = false, boost = 0.0, spool = 1000, kit = kit, kitId = kitId }
end

-- ===== Air suspension =====
-- Seviye 1 (en alçak) .. N (normal). Üç yöntem birlikte çalışır:
--   1) Araç modu "Suspension" (mod 15): kademeli ve ağda senkron. SADECE aracın sahibi (network owner) ayarlar,
--      diğer istemciler ağ senkronundan alır (aksi halde mod sürekli eski haline dönerdi)
--   2) fSuspensionRaise: her istemcide yerel, yumuşak ek alçalma (animasyonlu)
--   3) Tekerlek kamberi: alçalınca otomatik
local airLevel = {}     -- [entity] = uygulanan etkin seviye
local airCur = {}       -- [entity] = şu anki poz (0 = normal .. 1 = en alçak)
local airTarget = {}    -- [entity] = hedef poz (animasyon bitince silinir)
local airRefreshAt = {} -- [entity] = son yenileme zamanı
local airAuto = {}      -- [entity] = yüksek hızda otomatik yükselme aktif mi

local function isOwner(veh)
    return NetworkHasControlOfEntity(veh)
end

local function airModFor(veh, level)
    local cfg = Config.Air
    local o = getOriginals(veh)
    local n = GetNumVehicleMods(veh, 15)
    if n <= 0 then return nil end
    local t = (cfg.levels - level) / (cfg.levels - 1)
    if t <= 0 then return o.suspMod or -1 end                    -- normal yükseklik: oyuncunun kendi modu korunur
    return math.max(0, math.min(n - 1, math.ceil(t * n) - 1))
end

local function airSetMod(veh, idx, force)
    if idx == nil or not isOwner(veh) then return end
    if not force and GetVehicleMod(veh, 15) == idx then return end
    SetVehicleModKit(veh, 0)
    SetVehicleMod(veh, 15, idx, false)
end

local function airPose(veh, t)
    local o = getOriginals(veh)
    local cfg = Config.Air
    if cfg.useRaise then
        pcall(setF, veh, 'fSuspensionRaise', (o.fSuspensionRaise or 0.0) + cfg.lowestRaise * t)
    end
    local camber = cfg.camber * t * cfg.camberSign
    local wheels = GetVehicleNumberOfWheels(veh)
    for i = 0, wheels - 1 do
        local sign = (i % 2 == 0) and 1.0 or -1.0               -- çift = sol, tek = sağ
        pcall(SetVehicleWheelYRotation, veh, i, camber * sign)
    end
end

-- Etkin seviye: kullanıcının seviyesi, sürücü için yüksek hızda otomatik yükselmeyle (histerezisli)
function Abyss.AirEffective(veh, tune)
    local cfg = Config.Air
    local lvl = tune.airLevel or cfg.levels
    local ped = PlayerPedId()
    if GetPedInVehicleSeat(veh, -1) == ped then
        local speed = GetEntitySpeed(veh)
        if airAuto[veh] then
            if speed < cfg.autoRaiseSpeed - (cfg.autoRaiseHysteresis or 4.0) then airAuto[veh] = nil end
        elseif speed > cfg.autoRaiseSpeed then
            airAuto[veh] = true
        end
        if airAuto[veh] and lvl < cfg.autoRaiseLevel then lvl = cfg.autoRaiseLevel end
    else
        airAuto[veh] = nil
    end
    return lvl
end

function Abyss.ApplyAir(veh, level)
    if not veh or veh == 0 or not DoesEntityExist(veh) then return end
    local cfg = Config.Air
    level = math.max(1, math.min(cfg.levels, math.floor(level or cfg.levels)))
    if airLevel[veh] == level then return end                    -- zaten bu seviyede

    getOriginals(veh)
    local t = (cfg.levels - level) / (cfg.levels - 1)
    if cfg.useSuspensionMod then pcall(airSetMod, veh, airModFor(veh, level)) end

    if airCur[veh] == nil then
        airCur[veh] = t                                          -- ilk uygulama: animasyonsuz
        airPose(veh, t)
        airTarget[veh] = nil
    else
        airTarget[veh] = t                                       -- sonraki değişiklikler yavaşça
    end
    airLevel[veh] = level
end

function Abyss.ResetAir(veh)
    local o = originals[veh]
    pcall(airPose, veh, 0.0)
    if o and isOwner(veh) then
        pcall(function() SetVehicleModKit(veh, 0); SetVehicleMod(veh, 15, o.suspMod or -1, false) end)
    end
    airLevel[veh], airCur[veh], airTarget[veh], airRefreshAt[veh], airAuto[veh] = nil, nil, nil, nil, nil
end

-- Geçiş animasyonu: poz hedefe doğru yumuşakça kayar
CreateThread(function()
    while true do
        if next(airTarget) then
            Wait(0)
            local dt = GetFrameTime()
            local now = GetGameTimer()
            for veh, tgt in pairs(airTarget) do
                if not DoesEntityExist(veh) then
                    airTarget[veh], airCur[veh] = nil, nil
                else
                    local cur = airCur[veh] or tgt
                    local step = dt / math.max(0.1, Config.Air.transition)
                    local done = false
                    if math.abs(tgt - cur) <= step then
                        cur = tgt
                        done = true
                    else
                        cur = cur + ((tgt > cur) and step or -step)
                    end
                    airCur[veh] = cur
                    airPose(veh, cur)
                    -- fSuspensionRaise süspansiyon yeniden okunduğunda uygulanır: sahibi modu aynı değerle tazeler
                    if Config.Air.useRaise and Config.Air.useSuspensionMod and isOwner(veh)
                        and (done or now - (airRefreshAt[veh] or 0) >= Config.Air.refreshMs) then
                        airRefreshAt[veh] = now
                        local idx = airModFor(veh, airLevel[veh] or Config.Air.levels)
                        pcall(airSetMod, veh, idx, true)
                    end
                    if done then airTarget[veh] = nil end
                end
            end
        else
            Wait(200)
        end
    end
end)

-- Sahiplik bekçisi: araç bana geçerse mod seviyesini ben düzeltirim; yok olan araçlar temizlenir
CreateThread(function()
    while true do
        Wait(700)
        for veh, level in pairs(airLevel) do
            if not DoesEntityExist(veh) then
                airLevel[veh], airCur[veh], airTarget[veh], airRefreshAt[veh], airAuto[veh] = nil, nil, nil, nil, nil
            elseif Config.Air.useSuspensionMod and not airTarget[veh] and isOwner(veh) then
                pcall(airSetMod, veh, airModFor(veh, level))
            end
        end
    end
end)

-- Yüksek hızda otomatik yüksel, yavaşlayınca kullanıcının seviyesine dön
CreateThread(function()
    while true do
        Wait(300)
        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)
        local tune = veh ~= 0 and Abyss.active[veh] or nil
        if tune and (tune.air or not Config.Air.requireKit) and GetPedInVehicleSeat(veh, -1) == ped then
            local want = Abyss.AirEffective(veh, tune)
            if airLevel[veh] ~= want then pcall(Abyss.ApplyAir, veh, want) end
        end
    end
end)

-- Teşhis: /airdebug (araçtayken ya da yanındayken) F8 konsoluna ve bildirime sonuç yazar
RegisterCommand('airdebug', function()
    local veh = Abyss.GetTargetVehicle()
    if veh == 0 then return lib.notify({ type = 'error', description = 'Yakında araç yok.' }) end
    local tune = Abyss.active[veh]
    local o = originals[veh]
    local n = GetNumVehicleMods(veh, 15)
    local raise = GetVehicleHandlingFloat(veh, 'CHandlingData', 'fSuspensionRaise')
    local msg = ('air=%s kayitli=%s uygulanan=%s | suspension mod sayisi=%d, mevcut=%d | sahip=%s | fSuspensionRaise=%.3f (orijinal %.3f) | kamber native=%s')
        :format(tostring(tune and tune.air), tostring(tune and tune.airLevel), tostring(airLevel[veh]), n, GetVehicleMod(veh, 15),
            tostring(isOwner(veh)), raise, o and o.fSuspensionRaise or 0.0, tostring(SetVehicleWheelYRotation ~= nil))
    print('[abyss_tuning] ' .. msg)
    lib.notify({ type = 'inform', description = msg, duration = 9000 })
end, false)

function Abyss.ApplyTune(veh, tune)
    if not veh or veh == 0 or not DoesEntityExist(veh) or not tune then return end

    local o = getOriginals(veh)
    local stage = Config.Stages[tune.stage] or Config.Stages.stock
    local gear = Config.Gearboxes[tune.gearbox] or Config.Gearboxes.standard
    local mode = Config.Modes[tune.mode] or Config.Modes.normal

    local driveMult = stage.driveForce * (1.0 + mode.power * 0.012)
    local shiftMult = stage.shift * gear.shift * mode.shift * (Config.ShiftBoost or 1.0)

    setF(veh, 'fInitialDriveForce', o.fInitialDriveForce * driveMult)
    setF(veh, 'fInitialDriveMaxFlatVel', o.fInitialDriveMaxFlatVel * stage.topSpeed * mode.topSpeed)
    setF(veh, 'fClutchChangeRateScaleUpShift', o.fClutchChangeRateScaleUpShift * shiftMult)
    setF(veh, 'fClutchChangeRateScaleDownShift', o.fClutchChangeRateScaleDownShift * shiftMult)
    local E = Config.EcuTune
    local ecu = tune.ecu or E.defaults
    local tp = E.throttle[ecu.throttle or E.defaults.throttle] or E.throttle.street
    setF(veh, 'fDriveInertia', o.fDriveInertia * stage.response * mode.response * tp.resp)

    -- Hız limitörü (sadece ayar açıkken ya da daha önce açıksa dokun)
    if ecu.speedLimitOff == false then
        SetVehicleMaxSpeed(veh, (ecu.speedLimit or 250) / 3.6)
        limiterApplied[veh] = true
    elseif limiterApplied[veh] then
        SetVehicleMaxSpeed(veh, 0.0)
        limiterApplied[veh] = nil
    end
    setF(veh, 'fInitialDragCoeff', o.fInitialDragCoeff * stage.aero)

    local tractionMult = (tune.esp == false) and Config.ESP.offTractionLoss or 1.0
    setF(veh, 'fTractionLossMult', o.fTractionLossMult * tractionMult)
    -- Kalkış menüsü: patinaj ayarı arttıkça düşük hız çekiş kaybı artar (0 = stage'in değeri, 100 = burnout)
    local LM = Config.LaunchMenu
    local sN = math.max(0.0, math.min(1.0, (tune.launchSlip or LM.defaultSlip) / 100.0))
    local lowTr = (stage.lowTraction or 1.0) + (LM.maxSlipTraction - (stage.lowTraction or 1.0)) * (sN ^ 1.5)
    setF(veh, 'fLowSpeedTractionLossMult', o.fLowSpeedTractionLossMult * tractionMult * lowTr)
    setF(veh, 'fTractionCurveMax', o.fTractionCurveMax * (stage.grip or 1.0))
    setF(veh, 'fTractionCurveMin', o.fTractionCurveMin * (stage.grip or 1.0))
    -- Yüksek stage'de itiş dağıtımı öne kayar (kalkışta çok daha iyi tutuş)
    local bias = o.fDriveBiasFront + (0.5 - o.fDriveBiasFront) * (stage.awd or 0.0)
    setF(veh, 'fDriveBiasFront', bias)

    -- Fren geliştirme
    local brake = Config.Brakes[tune.brakes or 'stock'] or Config.Brakes.stock
    setF(veh, 'fBrakeForce', o.fBrakeForce * brake.force)
    setF(veh, 'fHandBrakeForce', o.fHandBrakeForce * brake.handbrake)

    -- Stage'de turbo varsa GTA turbo modunu aç (ses ve gösterge için)
    ToggleVehicleMod(veh, 18, Abyss.TurboParams(tune).enabled)

    -- Motor sesi
    local audio = o.audio
    for _, s in ipairs(Config.Sounds) do
        if s.id == tune.sound then
            audio = s.audio or o.audio
            break
        end
    end
    -- Egzoz vanası takılı ama kumandadan kapatılmışsa egzoz stok gibi: motor sesi orijinale döner
    if Config.Effects.closedValveStockSound and tune.valveOwned and not tune.valve then
        audio = o.audio
    end
    if audio then ForceVehicleEngineAudio(veh, audio) end

    -- Air suspension (kit takılıysa ya da kit şartı kapalıysa)
    local airOn = tune.air or not Config.Air.requireKit
    local okAir = pcall(function()
        if airOn then
            Abyss.ApplyAir(veh, Abyss.AirEffective(veh, tune))
        elseif airLevel[veh] then
            Abyss.ResetAir(veh)
        end
    end)
    if not okAir then print('[abyss_tuning] air suspension uygulanamadı (araç: ' .. tostring(veh) .. ')') end

    Abyss.active[veh] = tune
end

-- ===== State bag senkronu =====
AddStateBagChangeHandler('abyss:tune', nil, function(bagName, _, value)
    if not value then return end
    local tries = 0
    local ent = GetEntityFromStateBagName(bagName)
    while (ent == 0 or not DoesEntityExist(ent)) and tries < 40 do
        Wait(100)
        tries = tries + 1
        ent = GetEntityFromStateBagName(bagName)
    end
    if ent ~= 0 and DoesEntityExist(ent) and IsEntityAVehicle(ent) then
        Abyss.ApplyTune(ent, value)
    end
end)

-- Yakındaki araçlar için kayıtlı tune'u iste (her araç için bir kez)
local requested = {}
CreateThread(function()
    while true do
        Wait(2500)
        local coords = GetEntityCoords(PlayerPedId())
        for _, veh in ipairs(GetGamePool('CVehicle')) do
            if not requested[veh] and #(GetEntityCoords(veh) - coords) < 70.0 then
                requested[veh] = true
                local state = Entity(veh).state['abyss:tune']
                if state then
                    Abyss.ApplyTune(veh, state)
                elseif NetworkGetEntityIsNetworked(veh) then
                    TriggerServerEvent('abyss_tuning:server:requestSync',
                        NetworkGetNetworkIdFromEntity(veh), Abyss.GetPlate(veh))
                end
            end
        end
        -- temizlik
        for ent in pairs(requested) do
            if not DoesEntityExist(ent) then
                requested[ent] = nil
                originals[ent] = nil
                Abyss.active[ent] = nil
            end
        end
    end
end)

-- ===== Sürüş döngüsü: güç, ısınma, ESP desteği =====
local function slipAngle(veh)
    local vel = GetEntityVelocity(veh)
    local speed = #vel
    local fwd = GetEntityForwardVector(veh)
    local dot = vel.x * fwd.x + vel.y * fwd.y
    local cross = vel.x * fwd.y - vel.y * fwd.x
    return math.deg(math.atan(cross, dot)), speed, dot
end

local tcFactor = 1.0
local lcHoldSince, lcArmed, lcBoostUntil = 0, false, 0

CreateThread(function()
    while true do
        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)
        local tune = veh ~= 0 and Abyss.active[veh] or nil

        if veh ~= 0 and tune and GetPedInVehicleSeat(veh, -1) == ped and GetIsVehicleEngineRunning(veh) then
            Wait(0)
            local stage = Config.Stages[tune.stage] or Config.Stages.stock
            local mode = Config.Modes[tune.mode] or Config.Modes.normal
            local throttle = GetControlNormal(0, 71)
            local dt = GetFrameTime()

            -- Güç: stage + sürüş modu + turbo basıncı
            -- Turbo basıncı hissedilir: basınç dolunca (boost^2) araç bir anda basar
            local tpar = Abyss.TurboParams(tune)
            local turboPower = 0.0
            if tpar.enabled then
                turboPower = (Abyss.boost ^ 2) * tpar.boost * Config.Turbo.kick
            end
            local extra = stage.power + mode.power + turboPower

            -- ECU Settings (tablet): gaz tepkisi, yakıt haritası, ateşleme
            local E = Config.EcuTune
            local ecu = tune.ecu or E.defaults
            local tp = E.throttle[ecu.throttle or E.defaults.throttle] or E.throttle.street
            local tm = E.timing[ecu.timing or E.defaults.timing] or E.timing.normal
            local fuelStep = (ecu.fuel or 50) - 50
            extra = extra + tp.power + tm.power + fuelStep * E.fuel.powerPerStep
            local heatMult = tm.heat * (1.0 + fuelStep * E.fuel.heatPerStep)
            local now = GetGameTimer()
            local rpmNow = GetVehicleCurrentRpm(veh)
            local brakeIn = GetControlNormal(0, 72)
            local torqueMult = 1.0 + ((Abyss.boost ^ 2) * tpar.boost * Config.Turbo.torque)

            local speed = GetEntitySpeed(veh)

            -- Kalkış menüsü değerleri (tablet > LAUNCH)
            local LM = Config.LaunchMenu
            local pN = math.max(0.0, math.min(1.0, (tune.launchPower or LM.defaultPower) / 100.0))
            local sN = math.max(0.0, math.min(1.0, (tune.launchSlip or LM.defaultSlip) / 100.0))
            local launchMin = LM.launchMinLow + (1.0 - LM.launchMinLow) * pN
            local boost = LM.boostMin + (LM.boostMax - LM.boostMin) * pN

            -- Çekiş kontrolü (ESP açıkken): kalkış gücü + kayma oranına göre yumuşak güç ayarı
            if tune.esp ~= false and Config.TC.enabled then
                if speed < Config.TC.launchSpeed then
                    local startFactor = launchMin * boost
                    extra = extra * (startFactor + (1.0 - startFactor) * (speed / Config.TC.launchSpeed))
                end
                local target = 1.0
                if throttle > 0.4 then
                    local spin = 0.0
                    for w = 0, 3 do
                        local ws = math.abs(GetVehicleWheelSpeed(veh, w))
                        if ws > spin then spin = ws end
                    end
                    local slip = spin - speed
                    -- izin verilen kayma hızla birlikte büyür: yüksek hızda güç kesilip hız takılmaz
                    local slipTarget = Config.TC.slipTarget + (LM.slipTargetMax - Config.TC.slipTarget) * sN
                    local limit = math.max(slipTarget, speed * Config.TC.maxRatio * (1.0 + 2.0 * sN))
                    local slipGain = Config.TC.slipGain + (LM.slipGainMin - Config.TC.slipGain) * sN
                    if slip > limit then
                        target = math.max(Config.TC.minFactor, 1.0 - (slip - limit) * slipGain)
                    end
                end
                tcFactor = tcFactor + (target - tcFactor) * math.min(1.0, dt * Config.TC.response)
                extra = extra * tcFactor
                torqueMult = 1.0 + (torqueMult - 1.0) * tcFactor
            else
                tcFactor = 1.0
            end

            -- Kalkış desteği: düz kalkışta yanlamayı ve savrulmayı söndürür; patinaj ayarı arttıkça zayıflar
            local L = Config.Launch
            local assist = 1.0 - 0.95 * sN
            if L.enabled and assist > 0.1 and speed < L.maxSpeed and throttle > L.minThrottle and not IsControlPressed(0, 76)
                and math.abs(GetControlNormal(0, 59)) < L.steerLimit and IsVehicleOnAllWheels(veh) then
                local vel = GetEntityVelocity(veh)
                local fwd = GetEntityForwardVector(veh)
                local rx, ry = fwd.y, -fwd.x                        -- aracın sağ vektörü
                local lat = vel.x * rx + vel.y * ry                 -- yanal hız
                local k = 1.0 - math.exp(-L.latStrength * assist * dt)
                SetEntityVelocity(veh, vel.x - rx * lat * k, vel.y - ry * lat * k, vel.z)
                local av = GetEntityRotationVelocity(veh)
                SetEntityAngularVelocity(veh, av.x, av.y, av.z * math.exp(-L.yawStrength * assist * dt))
            end

            -- ABS: sert frenlemede aracı düz tutar
            if tune.abs then
                local A = Config.ABS
                local vel = GetEntityVelocity(veh)
                local fwd = GetEntityForwardVector(veh)
                local fwdSpeed = vel.x * fwd.x + vel.y * fwd.y
                if GetControlNormal(0, 72) > A.minBrake and fwdSpeed > A.minSpeed and not IsControlPressed(0, 76)
                    and IsVehicleOnAllWheels(veh) then
                    local rx, ry = fwd.y, -fwd.x
                    local lat = vel.x * rx + vel.y * ry
                    local k = 1.0 - math.exp(-A.latStrength * dt)
                    SetEntityVelocity(veh, vel.x - rx * lat * k, vel.y - ry * lat * k, vel.z)
                    local av = GetEntityRotationVelocity(veh)
                    SetEntityAngularVelocity(veh, av.x, av.y, av.z * math.exp(-A.yawStrength * dt))
                end
            end

            -- Devir limitörü: ayarlanan RPM'de yakıt kesilir
            Abyss.limiter = false
            local rl = (ecu.revLimit or E.defaults.revLimit) / E.redlineRpm
            local gearNow, gearHigh = GetVehicleCurrentGear(veh), GetVehicleHighGear(veh)
            if rl < 0.995 and rpmNow >= rl and throttle > 0.3 and (not E.revLimitTopGearOnly or gearNow >= gearHigh) then
                torqueMult = 0.0
                Abyss.limiter = true
            end

            -- Launch Control (2-step): dururken fren + tam gaz ile devir tutulur, fren bırakılınca ek güçle fırlar
            local lcRpmVal = nil
            if (ecu.lcRpm or E.defaults.lcRpm) > E.lc.min then lcRpmVal = ecu.lcRpm end
            if Abyss.lcTestRpm then lcRpmVal = Abyss.lcTestRpm end       -- 0-100 testi kendi devrini tutar
            Abyss.lcHold = false
            if lcRpmVal and speed < 1.5 and throttle > 0.9 and brakeIn > 0.5 then
                Abyss.lcHold = true
                lcHoldSince = (lcHoldSince == 0) and now or lcHoldSince
                SetVehicleCurrentRpm(veh, math.min(1.0, lcRpmVal / E.redlineRpm))
                torqueMult = 0.0
                if now - lcHoldSince > 600 then lcArmed = true end
            else
                if lcArmed and throttle > 0.8 and brakeIn < 0.2 and speed < 8.0 then
                    lcBoostUntil = now + E.lc.window            -- fren bırakıldı: fırlat
                end
                lcHoldSince = 0
                if throttle < 0.3 then lcArmed = false end
            end
            Abyss.lcArmed = lcArmed
            if now < lcBoostUntil then extra = extra * E.lc.boost end

            -- Rölanti devri (750 = fabrika)
            if throttle < 0.05 and speed < 1.5 and (ecu.idle or E.idle.base) > E.idle.base then
                local target = 0.2 + ((ecu.idle or E.idle.base) - E.idle.base) / E.redlineRpm
                if rpmNow < target then SetVehicleCurrentRpm(veh, target) end
            end

            -- Motor freni: %50 fabrika, üstü daha fazla yavaşlatır, altı daha az
            if throttle < 0.05 and brakeIn < 0.05 and speed > 4.0 then
                local delta = ((ecu.engBrake or 50) - 50) / 50.0 * E.engBrakeForce
                if math.abs(delta) > 0.001 then
                    local vel2 = GetEntityVelocity(veh)
                    local f = 1.0 - delta * dt
                    SetEntityVelocity(veh, vel2.x * f, vel2.y * f, vel2.z)
                end
            end

            SetVehicleEnginePowerMultiplier(veh, extra)
            SetVehicleEngineTorqueMultiplier(veh, torqueMult)

            -- Isınma: yüksek stage'de uzun süre tam gaz motoru yorar
            local load = (stage.power / 40.0) * (stage.power / 40.0)
            if throttle > 0.9 and GetEntitySpeed(veh) > 8.0 then
                Abyss.heat = math.min(1.0, Abyss.heat + dt * Config.Effects.heatPerSecond * (1.0 + load * 3.0) * heatMult)
            else
                Abyss.heat = math.max(0.0, Abyss.heat - dt * 0.05)
            end
            if Config.Effects.engineDamageAtFullHeat and Abyss.heat >= 1.0 and load > 0.3 then
                local health = GetVehicleEngineHealth(veh)
                if health > (Config.Effects.heatMinHealth or 650.0) then
                    SetVehicleEngineHealth(veh, health - (12.0 * dt))
                end
            end

            -- ESP desteği (açıkken aşırı savrulmayı sönümler)
            if tune.esp ~= false and not IsControlPressed(0, 76) then
                local angle, spd, dot = slipAngle(veh)
                if spd > Config.ESP.minSpeed and dot > 0 and math.abs(angle) > Config.ESP.assistAngle
                    and IsVehicleOnAllWheels(veh) then
                    local av = GetEntityRotationVelocity(veh)
                    SetEntityAngularVelocity(veh, av.x, av.y, av.z * (1.0 - Config.ESP.assistStrength))
                end
            end
        else
            Abyss.boost = 0.0
            Wait(300)
        end
    end
end)


-- ===== Radyo: araca binince / motor çalışınca kendiliğinden açılmasın =====
CreateThread(function()
    local lastVeh, engineWas = 0, false
    while true do
        Wait(250)
        if Config.Radio and Config.Radio.autoOff then
            local ped = PlayerPedId()
            local veh = GetVehiclePedIsIn(ped, false)
            if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then
                local running = GetIsVehicleEngineRunning(veh)
                if veh ~= lastVeh or (running and not engineWas) then
                    lastVeh = veh
                    SetVehRadioStation(veh, 'OFF')
                    SetRadioToStationName('OFF')
                    SetTimeout(900, function()                  -- oyun kısa süre sonra son istasyonu tekrar açabiliyor
                        if DoesEntityExist(veh) and GetVehiclePedIsIn(PlayerPedId(), false) == veh then
                            SetVehRadioStation(veh, 'OFF')
                        end
                    end)
                end
                engineWas = running
            else
                lastVeh, engineWas = 0, false
            end
        end
    end
end)

-- Araç kapısına yaklaşınca kumanda için handling temizliği gerekmez; kaynağı durdurunca eski değerleri geri yaz
AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    for veh, o in pairs(originals) do
        if DoesEntityExist(veh) then
            pcall(Abyss.ResetAir, veh)
            for _, f in ipairs(FLOATS) do if o[f] then setF(veh, f, o[f]) end end
            if o.audio then ForceVehicleEngineAudio(veh, o.audio) end
        end
    end
end)
