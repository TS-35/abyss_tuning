-- Turbo simülasyonu, blow-off, flutter, popcorn (pops & bangs) ve ses efektleri

local PTFX_ASSET = 'core'
local FX_BACKFIRE = 'veh_backfire'

function Abyss.PlaySound(name, volume)
    SendNUIMessage({ action = 'sound', data = { name = name, volume = volume or 0.6 } })
end

local function loadPtfx()
    if HasNamedPtfxAssetLoaded(PTFX_ASSET) then return true end
    RequestNamedPtfxAsset(PTFX_ASSET)
    local t = 0
    while not HasNamedPtfxAssetLoaded(PTFX_ASSET) and t < 50 do
        Wait(10)
        t = t + 1
    end
    return HasNamedPtfxAssetLoaded(PTFX_ASSET)
end

-- Aracın egzoz uçlarının dünya koordinatları
local BONES = { 'exhaust', 'exhaust_2', 'exhaust_3', 'exhaust_4' }
local function exhaustPoints(veh)
    local pts = {}
    for _, b in ipairs(BONES) do
        local idx = GetEntityBoneIndexByName(veh, b)
        if idx ~= -1 then
            pts[#pts + 1] = GetWorldPositionOfEntityBone(veh, idx)
        end
    end
    if #pts == 0 then
        -- bone yoksa aracın arkasına yaklaşık nokta
        pts[1] = GetOffsetFromEntityInWorldCoords(veh, 0.0, -2.2, 0.3)
    end
    return pts
end

local function backfire(veh)
    if not loadPtfx() then return end
    local rot = GetEntityRotation(veh, 2)
    for _, p in ipairs(exhaustPoints(veh)) do
        UseParticleFxAssetNextCall(PTFX_ASSET)
        StartNetworkedParticleFxNonLoopedAtCoord(FX_BACKFIRE, p.x, p.y, p.z, rot.x, rot.y, rot.z, 1.4, false, false, false)
    end
end


-- ===== Kara duman (looped, siyaha boyanır, state bag ile herkese senkron) =====
local smokeFx = {}   -- [veh] = { handles }

local function tint(h)
    local c = Config.Effects.smokeColor
    SetParticleFxLoopedColour(h, c[1], c[2], c[3], false)
    SetParticleFxLoopedAlpha(h, 1.0)
end

local function startSmoke(veh)
    if not veh or veh == 0 or not DoesEntityExist(veh) or smokeFx[veh] then return end
    if not loadPtfx() then return end
    local handles = {}
    local scale = Config.Effects.smokeScale or 1.8

    local bones = {}
    for _, b in ipairs(BONES) do
        local idx = GetEntityBoneIndexByName(veh, b)
        if idx ~= -1 then bones[#bones + 1] = idx end
    end

    local function spawn(boneIdx)
        for _, name in ipairs(Config.Effects.smokeFx) do
            UseParticleFxAssetNextCall(PTFX_ASSET)
            local h
            if boneIdx then
                h = StartParticleFxLoopedOnEntityBone(name, veh, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, boneIdx, scale, false, false, false)
            else
                h = StartParticleFxLoopedOnEntity(name, veh, 0.0, -2.1, 0.25, 0.0, 0.0, 0.0, scale, false, false, false)
            end
            if h and h ~= 0 and DoesParticleFxLoopedExist(h) then
                tint(h)
                handles[#handles + 1] = h
            end
        end
    end

    if #bones == 0 then spawn(nil) else for _, idx in ipairs(bones) do spawn(idx) end end
    smokeFx[veh] = handles
end

local function stopSmoke(veh)
    local handles = smokeFx[veh]
    if not handles then return end
    for _, h in ipairs(handles) do
        if DoesParticleFxLoopedExist(h) then StopParticleFxLooped(h, false) end
    end
    smokeFx[veh] = nil
end

-- Diğer oyuncuların (ve kendi) araçlarındaki duman durumu
AddStateBagChangeHandler('abyss:smoke', nil, function(bagName, _, value)
    local ent = GetEntityFromStateBagName(bagName)
    if ent == 0 or not DoesEntityExist(ent) then return end
    if value then startSmoke(ent) else stopSmoke(ent) end
end)

-- Rengi sürekli siyaha çek (bazı partiküller rengi sıfırlıyor) + uzaklaşan/yok olan araçları temizle
CreateThread(function()
    local me = vector3(0.0, 0.0, 0.0)
    while true do
        if next(smokeFx) then
            Wait(120)
            me = GetEntityCoords(PlayerPedId())
            for veh, handles in pairs(smokeFx) do
                if not DoesEntityExist(veh) or #(GetEntityCoords(veh) - me) > 120.0 then
                    stopSmoke(veh)
                else
                    for _, h in ipairs(handles) do
                        if DoesParticleFxLoopedExist(h) then tint(h) end
                    end
                end
            end
        else
            Wait(500)
        end
    end
end)

CreateThread(function()
    local nextPopAt, nextAlsAt = 0, 0
    local prevBoost = 0.0
    local lastBlow, nextTelemetry, telemetryOn = 0, 0, false
    local lastHighAt, fullSince, lastFlutter, prevThrottle = 0, 0, 0, 0.0
    local smokeOn, smokeVeh = false, 0

    while true do
        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)
        local tune = veh ~= 0 and Abyss.active[veh] or nil

        if tune and GetPedInVehicleSeat(veh, -1) == ped and GetIsVehicleEngineRunning(veh) then
            Wait(0)
            local stage = Config.Stages[tune.stage] or Config.Stages.stock
            local mode = Config.Modes[tune.mode] or Config.Modes.normal
            local throttle = GetControlNormal(0, 71)
            local rpm = GetVehicleCurrentRpm(veh)
            local dt = GetFrameTime()
            local now = GetGameTimer()

            -- ===== Turbo basıncı (kit + stage'e göre dolar; yüksek devirde daha hızlı) =====
            local tpar = Abyss.TurboParams(tune)
            if tpar.enabled then
                local spool = math.max(0.15, (tpar.spool or 1000) / 1000.0)
                local rate = 0.35 + rpm * 1.1
                if throttle > 0.3 and rpm > 0.3 then
                    Abyss.boost = math.min(1.0, Abyss.boost + dt / spool * rate * throttle)
                else
                    Abyss.boost = math.max(0.0, Abyss.boost - dt / (spool * 0.5))
                end

                -- Basınç tam dolunca hafif "tekme": araç bir anda basar
                if Config.Turbo.shake and Abyss.boost >= 0.9 and prevBoost < 0.9 and throttle > 0.8 then
                    ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.035)
                end

                -- Oyunun kendi turbo sesi: araca basınç değerini ver (native varsa)
                if Abyss.nativeTurbo == nil then Abyss.nativeTurbo = (type(SetVehicleTurboPressure) == 'function') end
                if Abyss.nativeTurbo then pcall(SetVehicleTurboPressure, veh, Abyss.boost) end

                -- Gaz kapanınca blow-off (basınç yüksekken): NUI'ye gönder
                if prevBoost > 0.45 and throttle < 0.15 and now - lastBlow > 700 then
                    lastBlow = now
                    Abyss.Send('turboBlow', { boost = prevBoost, pitch = tpar.kit.pitch, twin = tpar.kit.twin })
                end
                prevBoost = Abyss.boost

                -- Sürekli turbo sesi (yalnızca sürücü duyar): basınca bağlı NUI sesi / kayıt, oyunun native sesi yoksa
                local synth = Config.Turbo.synth
                if (synth == true) or (synth == 'auto' and not Abyss.nativeTurbo) then
                    if now >= nextTelemetry then
                        nextTelemetry = now + 50
                        telemetryOn = true
                        Abyss.Send('turbo', { on = true, boost = Abyss.boost, rpm = rpm, throttle = throttle,
                            pitch = tpar.kit.pitch, whine = tpar.kit.whine, twin = tpar.kit.twin })
                    end
                end
            else
                Abyss.boost, prevBoost = 0.0, 0.0
                if telemetryOn then telemetryOn = false; Abyss.Send('turbo', { on = false }) end
            end

            -- ===== Flutter / blow-off: yüksek devirde tam gazdan bir anda gaz kesilince, tek sefer =====
            local FL = Config.Effects.flutter
            if throttle > 0.85 and rpm >= FL.minRpm then
                if fullSince == 0 then fullSince = now end
                lastHighAt = now
            end
            if throttle < 0.12 and prevThrottle >= 0.12 then                       -- gaz tam o anda kesildi
                if fullSince ~= 0 and now - fullSince >= FL.minHold and now - lastHighAt <= FL.suddenMs
                    and rpm >= FL.minRpm * 0.9 and GetEntitySpeed(veh) > FL.minSpeed
                    and now - lastFlutter > FL.cooldown then
                    lastFlutter = now
                    if tune.flutter and tune.valve then Abyss.PlaySound('flutter', FL.volume) end
                end
                fullSince = 0
            elseif throttle < 0.12 then
                fullSince = 0
            end
            prevThrottle = throttle

            local ecu = tune.ecu or Config.EcuTune.defaults

            -- ===== Anti-lag (ALS): gaz bırakılınca turbo basıncı tutulur, egzozdan patlamalar gelir =====
            if ecu.als and throttle < 0.12 and rpm > 0.5 and GetEntitySpeed(veh) > 8.0 then
                Abyss.boost = math.max(Abyss.boost, 0.65)
                if tune.valve and now >= nextAlsAt and math.random() < 0.75 then
                    nextAlsAt = now + 140 + math.random(0, 170)
                    backfire(veh)
                    Abyss.PlaySound('pop', 0.55 + math.random() * 0.3)
                end
            end

            -- Devir limitöründe ve launch control'de ritmik patlamalar (egzoz vanası açıkken)
            if (Abyss.limiter or Abyss.lcHold) and tune.valve and now >= nextAlsAt then
                nextAlsAt = now + 110 + math.random(0, 120)
                backfire(veh)
                Abyss.PlaySound('pop', 0.5 + math.random() * 0.25)
            end

            -- ===== Popcorn (pops & bangs): vana açık + sport modları, aralık uzatılmış =====
            local P = Config.EcuTune.pops[ecu.pops or Config.EcuTune.defaults.pops] or Config.EcuTune.pops.street
            if tune.valve and mode.pops and P.chance > 0 and throttle < 0.1 and rpm > Config.Effects.popMinRpm
                and GetEntitySpeed(veh) > 6.0 and now >= nextPopAt then
                if math.random() < Config.Effects.popChance * P.chance then
                    nextPopAt = now + Config.Effects.popCooldown * P.cooldown + math.random(0, Config.Effects.popJitter)
                    backfire(veh)
                    Abyss.PlaySound('pop', 0.5 + math.random() * 0.25)
                end
            end

            -- ===== Kara duman: gaza basınca açılır, bırakınca kapanır =====
            local wantSmoke = tune.smoke and tune.valve and throttle > Config.Effects.smokeMinThrottle and rpm > 0.25
            if wantSmoke ~= smokeOn then
                smokeOn, smokeVeh = wantSmoke, veh
                if wantSmoke then startSmoke(veh) else stopSmoke(veh) end
                Entity(veh).state:set('abyss:smoke', wantSmoke, true)
            end

        else
            if smokeOn then
                smokeOn = false
                if DoesEntityExist(smokeVeh) then
                    stopSmoke(smokeVeh)
                    Entity(smokeVeh).state:set('abyss:smoke', false, true)
                end
            end
            fullSince, prevThrottle = 0, 0.0
            Abyss.boost, prevBoost = 0.0, 0.0
            if telemetryOn then telemetryOn = false; Abyss.Send('turbo', { on = false }) end
            Wait(300)
        end
    end
end)
