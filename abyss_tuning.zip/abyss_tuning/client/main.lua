local QBCore = exports['qb-core']:GetCoreObject()

-- Ortak durum (diğer client dosyaları da kullanır)
Abyss = {
    open = nil,        -- 'tablet' | 'fob' | nil
    veh = 0,
    plate = '',
    tune = nil,
    busy = false,
}

local function trim(s)
    return (tostring(s or ''):gsub('^%s+', ''):gsub('%s+$', ''):upper())
end

function Abyss.GetPlate(veh)
    return trim(GetVehicleNumberPlateText(veh))
end

local function send(action, data)
    SendNUIMessage({ action = action, data = data })
end
Abyss.Send = send

-- Yakındaki en uygun aracı bul (içindeysen o, değilse en yakın)
function Abyss.GetTargetVehicle()
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh ~= 0 then return veh end
    local coords = GetEntityCoords(ped)
    local closest, dist = 0, 8.0
    for _, v in ipairs(GetGamePool('CVehicle')) do
        local d = #(GetEntityCoords(v) - coords)
        if d < dist then closest, dist = v, d end
    end
    return closest
end

-- Aracın stock değerlerinden NUI için önizleme tabanı üret
local function buildBase(veh)
    local mass = GetVehicleHandlingFloat(veh, 'CHandlingData', 'fMass')
    local force = GetVehicleHandlingFloat(veh, 'CHandlingData', 'fInitialDriveForce')
    local model = GetEntityModel(veh)
    local stockHP = math.floor(force * mass * Config.Dyno.hpScale)
    if stockHP < 40 then stockHP = 40 end
    local topKmh = math.floor((GetVehicleModelEstimatedMaxSpeed(model) or 40.0) * 3.6)
    local name = GetDisplayNameFromVehicleModel(model)
    local label = GetLabelText(name)
    if label == 'NULL' then label = name end
    local make = GetLabelText(GetMakeNameFromVehicleModel(model))
    if make ~= 'NULL' and make ~= '' then label = make .. ' ' .. label end
    return {
        hp = stockHP,
        torque = math.floor(stockHP * Config.Dyno.torquePerHp),
        topSpeed = topKmh,
        name = label,
    }
end

-- ===== Tablet =====
local function openTablet()
    if Abyss.open then return end
    local allowed = lib.callback.await('abyss_tuning:canOpen', false)
    if not allowed then
        lib.notify({ type = 'error', description = 'Bu tableti kullanma yetkin yok.' })
        return
    end

    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then
        lib.notify({ type = 'error', description = 'Tableti kullanmak için bir aracın içinde olmalısın.' })
        return
    end
    if Config.RequireDriverSeat and GetPedInVehicleSeat(veh, -1) ~= ped then
        lib.notify({ type = 'error', description = 'Sürücü koltuğunda olmalısın.' })
        return
    end

    local plate = Abyss.GetPlate(veh)
    local tune = lib.callback.await('abyss_tuning:getTune', false, plate)

    Abyss.open, Abyss.veh, Abyss.plate, Abyss.tune = 'tablet', veh, plate, tune
    SetNuiFocus(true, true)
    send('openTablet', {
        plate = plate,
        base = buildBase(veh),
        tune = tune,
        config = {
            stages = Config.Stages, stageOrder = Config.StageOrder,
            gearboxes = Config.Gearboxes, gearboxOrder = Config.GearboxOrder,
            sounds = Config.Sounds, exhaust = Config.ExhaustFx,
            modes = Config.Modes, flashDuration = Config.FlashDuration,
            dyno = Config.Dyno, exhaustOrder = Config.ExhaustFxOrder,
            brakes = Config.Brakes, brakeOrder = Config.BrakeOrder, abs = Config.ABS,
            baseStopMeters = Config.BaseStopMeters, launchMenu = Config.LaunchMenu, ecuTune = Config.EcuTune, air = Config.Air, turbo = Config.Turbo, launchTest = Config.LaunchTest, ecuLock = Config.EcuLock,
            baseShiftMs = Config.BaseShiftMs,
        },
    })
end

RegisterCommand(Config.Command, openTablet, false)

local function closeUI()
    if not Abyss.open then return end
    Abyss.open = nil
    SetNuiFocus(false, false)
    send('close', {})
end
Abyss.Close = closeUI

RegisterNUICallback('close', function(_, cb)
    if Abyss.busy then cb('busy') return end
    closeUI()
    cb('ok')
end)

-- Flash isteği
RegisterNUICallback('flash', function(sel, cb)
    if Abyss.busy then cb({ ok = false, msg = 'İşlem sürüyor.' }) return end
    local veh = Abyss.veh
    if veh == 0 or not DoesEntityExist(veh) then cb({ ok = false, msg = 'Araç bulunamadı.' }) return end
    if Config.RequireEngineOffForFlash and GetIsVehicleEngineRunning(veh) then
        cb({ ok = false, msg = 'Önce motoru kapat.' }) return
    end

    Abyss.busy = true
    local res = lib.callback.await('abyss_tuning:flash', false, NetworkGetNetworkIdFromEntity(veh), Abyss.plate, sel)
    if res and res.ok then
        Abyss.tune = res.tune
        Abyss.ApplyTune(veh, res.tune)
        cb({ ok = true, tune = res.tune, price = res.price })
    else
        Abyss.busy = false
        cb({ ok = false, msg = res and res.msg or 'İşlem başarısız.' })
    end
end)

RegisterNUICallback('fitAir', function(_, cb)
    local veh = Abyss.veh
    if veh == 0 or not DoesEntityExist(veh) then cb({ ok = false, msg = 'Araç bulunamadı.' }) return end
    local res = lib.callback.await('abyss_tuning:fitAir', false, NetworkGetNetworkIdFromEntity(veh), Abyss.plate)
    if res and res.ok then
        Abyss.tune = res.tune
        Abyss.ApplyTune(veh, res.tune)
        cb({ ok = true, tune = res.tune, price = res.price })
    else
        cb({ ok = false, msg = res and res.msg or 'İşlem başarısız.' })
    end
end)

RegisterNUICallback('launchTest', function(_, cb)
    cb({ ok = Abyss.StartLaunchTest() })
end)

-- ECU kilidi: minigame başlangıcı / sonucu (sunucu bilet verir)
RegisterNUICallback('lockBegin', function(_, cb)
    local res = lib.callback.await('abyss_tuning:lock:begin', false) or { ok = true }
    if res.ok then Abyss.busy = true end            -- minigame sırasında ESC tableti kapatmasın
    cb(res)
end)

RegisterNUICallback('lockDone', function(d, cb)
    local res = lib.callback.await('abyss_tuning:lock:done', false, d.ok == true, d.cancelled == true) or { ok = false }
    if not res.ok then Abyss.busy = false end
    cb(res)
end)

RegisterNUICallback('flashDone', function(_, cb)
    Abyss.busy = false
    cb('ok')
end)

-- Dyno isteği
RegisterNUICallback('dyno', function(_, cb)
    local ok = Abyss.RunDyno()
    cb({ ok = ok })
end)

-- ===== Araç kumandası =====
RegisterNetEvent('abyss_tuning:client:useFob', function()
    if Abyss.open then return end
    local veh = Abyss.GetTargetVehicle()
    if veh == 0 then
        lib.notify({ type = 'error', description = 'Yakında kumandayla eşleşen araç yok.' })
        return
    end
    local plate = Abyss.GetPlate(veh)
    local tune = lib.callback.await('abyss_tuning:getTune', false, plate)
    Abyss.open, Abyss.veh, Abyss.plate, Abyss.tune = 'fob', veh, plate, tune
    SetNuiFocus(true, true)
    send('openFob', { plate = plate, tune = tune, modes = Config.Modes, modeOrder = Config.ModeOrder, air = Config.Air })
end)

RegisterNUICallback('fobSet', function(d, cb)
    local veh = Abyss.veh
    if veh == 0 or not DoesEntityExist(veh) then cb({ ok = false }) return end
    local res = lib.callback.await('abyss_tuning:fob:set', false,
        NetworkGetNetworkIdFromEntity(veh), Abyss.plate, d.field, d.value)
    if res and res.ok then
        Abyss.tune = res.tune
        Abyss.ApplyTune(veh, res.tune)
        cb({ ok = true, tune = res.tune })
    else
        cb({ ok = false, msg = res and res.msg or nil })
    end
end)

-- ESC ile kapat
CreateThread(function()
    while true do
        if Abyss.open then
            Wait(0)
            DisableControlAction(0, 200, true)
            if IsDisabledControlJustPressed(0, 200) and not Abyss.busy then closeUI() end
        else
            Wait(500)
        end
    end
end)

AddEventHandler('onResourceStop', function(res)
    if res == GetCurrentResourceName() and Abyss.open then SetNuiFocus(false, false) end
end)
