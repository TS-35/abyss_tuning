Config = {}

-- ===== Genel =====
Config.Command          = 'tuningtablet'   -- sohbete yazılacak komut (/tuningtablet)
Config.FobItem          = 'abyss_keyfob'   -- araç kumandası itemi
Config.AllowedJobs      = {}               -- {'mechanic', 'tuner'} -> boşsa herkes kullanır
Config.RequireDriverSeat = true            -- tablet için sürücü koltuğunda olmak gerekir
Config.RequireOwnedVehicle = false         -- true: sadece player_vehicles'ta sana ait araç
Config.PayWith          = 'bank'           -- 'bank' veya 'cash'
Config.FlashDuration    = 9000             -- ms, yazma ekranı süresi
Config.RequireEngineOffForFlash = false    -- true: flash için motor kapalı olmalı
Config.BaseShiftMs      = 420              -- standart şanzımanın vites süresi (ms), arayüzde gösterilir
Config.ShiftBoost       = 1.9              -- gerçek vites hızı çarpanı (arayüzdeki değere ek, 'seri vites' hissi)

-- ===== Stage'ler =====
-- powerPct   : arayüzde gösterilen güç artışı (HP/Nm buna göre hesaplanır)
-- power      : SetVehicleEnginePowerMultiplier'a eklenen değer
-- driveForce : fInitialDriveForce çarpanı
-- topSpeed   : fInitialDriveMaxFlatVel çarpanı (arayüzdeki "Top Speed" artışı)
-- shift      : vites geçiş hızı çarpanı
-- response   : devir tepkisi (fDriveInertia çarpanı, düşük = daha hızlı devir alır)
-- aero       : fInitialDragCoeff çarpanı (düşük = daha az sürtünme, daha yüksek son hız)
-- grip       : fTractionCurveMax/Min çarpanı (yüksek stage'de lastik tutuşu artar)
-- lowTraction: fLowSpeedTractionLossMult çarpanı (düşük = kalkışta daha az patinaj)
-- awd        : itişin ne kadarı öne dağıtılır (0 = araç neyse o, 0.5 = tam AWD'ye doğru) -> kalkışta tutuş
-- turbo      : boost = azami ek güç, spool = ms cinsinden dolum süresi
Config.Stages = {
    stock  = { label = 'Stock',   tag = 'FACTORY',     color = '#e8e8ee', price = 0,     title = 'Original',              desc = "The vehicle's factory software and values.",
               power = 0.0,  driveForce = 1.00, topSpeed = 1.00, shift = 1.00, response = 1.00, aero = 1.00, grip = 1.00, lowTraction = 1.00, awd = 0.00,
               turbo = { enabled = false }, powerPct = 0 },
    stage1 = { label = 'Stage 1', tag = 'DAILY',       color = '#5eead4', price = 2500,  title = 'Software Optimization', desc = 'Balanced power gain and sharper throttle response for daily driving.',
               power = 8.0,  driveForce = 1.15, topSpeed = 1.10, shift = 1.25, response = 0.95, aero = 0.99, grip = 1.08, lowTraction = 0.80, awd = 0.05,
               turbo = { enabled = true, boost = 0.35, spool = 1400 }, powerPct = 25 },
    stage2 = { label = 'Stage 2', tag = 'PERFORMANCE', color = '#4ade80', price = 5000,  title = 'Performance Map',       desc = 'Aggressive fuel and ignition map with a clear acceleration gain.',
               power = 18.0, driveForce = 1.34, topSpeed = 1.20, shift = 1.60, response = 0.90, aero = 0.97, grip = 1.16, lowTraction = 0.58, awd = 0.15,
               turbo = { enabled = true, boost = 0.60, spool = 1100 }, powerPct = 50 },
    stage3 = { label = 'Stage 3', tag = 'TRACK',       color = '#ffc933', price = 10000, title = 'Track & Drag',          desc = 'Full-load map for track use. Engine heats up faster under sustained load.',
               power = 32.0, driveForce = 1.58, topSpeed = 1.35, shift = 2.00, response = 0.85, aero = 0.94, grip = 1.26, lowTraction = 0.34, awd = 0.30,
               turbo = { enabled = true, boost = 0.90, spool = 850 }, powerPct = 75 },
    stage4 = { label = 'Stage 4', tag = 'RACE',        color = '#ff4d6d', price = 20000, title = 'Race / Custom ECU',     desc = 'Race ECU map. Limits are removed and heat becomes a real risk.',
               power = 58.0, driveForce = 1.95, topSpeed = 1.50, shift = 2.80, response = 0.80, aero = 0.90, grip = 1.40, lowTraction = 0.12, awd = 0.45,
               turbo = { enabled = true, boost = 1.30, spool = 600 }, powerPct = 110 },
}
Config.StageOrder = { 'stock', 'stage1', 'stage2', 'stage3', 'stage4' }

-- ===== Şanzıman yazılımı =====
-- shift: vites hızı çarpanı, ms = BaseShiftMs / shift, pattern: arayüzdeki vites şeması ('h' | 'seq')
Config.Gearboxes = {
    standard = { label = 'Standard Gearbox',         desc = 'Factory standard gearbox and gear ratios.',                       price = 0,    shift = 1.0, pattern = 'h' },
    short    = { label = 'Short Shifter',            desc = 'Performance shift kit that shortens shift travel and time.',      price = 3000, shift = 2.2, pattern = 'h' },
    drift    = { label = 'Drift Spec Gearbox',       desc = 'Wide gear ratios for wheelspin and sliding at high revs.',        price = 5000, shift = 1.8, pattern = 'h' },
    seq      = { label = 'Sequential Race Gearbox',  desc = 'Race gearbox with millisecond shifts for maximum acceleration.',  price = 8000, shift = 3.5, pattern = 'seq' },
}
Config.GearboxOrder = { 'standard', 'short', 'drift', 'seq' }

-- ===== Fren geliştirme =====
-- force: fBrakeForce çarpanı, handbrake: fHandBrakeForce çarpanı
Config.Brakes = {
    stock  = { label = 'Stock',  tag = 'FACTORY', color = '#e8e8ee', price = 0,     title = 'Original Brakes',        desc = 'Factory pads, discs and calipers.',
               force = 1.00, handbrake = 1.00 },
    street = { label = 'Street', tag = 'STREET',  color = '#5eead4', price = 1500,  title = 'Street Pads & Lines',    desc = 'Sharper pads and braided lines for firmer, more consistent stopping.',
               force = 1.25, handbrake = 1.15 },
    sport  = { label = 'Sport',  tag = 'SPORT',   color = '#4ade80', price = 3500,  title = 'Sport Big Brake Kit',    desc = 'Larger drilled discs and 4-piston calipers for strong, repeatable stops.',
               force = 1.55, handbrake = 1.30 },
    race   = { label = 'Race',   tag = 'RACE',    color = '#ffc933', price = 7000,  title = 'Race Calipers & Discs',  desc = 'Race compound pads with 6-piston calipers. Heavy stopping power.',
               force = 1.90, handbrake = 1.50 },
    carbon = { label = 'Carbon', tag = 'CARBON',  color = '#ff4d6d', price = 12000, title = 'Carbon-Ceramic Kit',     desc = 'Carbon-ceramic discs. The shortest stopping distances available.',
               force = 2.35, handbrake = 1.70 },
}
Config.BrakeOrder = { 'stock', 'street', 'sport', 'race', 'carbon' }
Config.BaseStopMeters = 42.0   -- 100-0 km/h için stock fren mesafesi tahmini (arayüzde gösterilir)

-- ABS: sert frenlemede aracı düz tutar (yanal kaymayı ve savrulmayı söndürür)
Config.ABS = {
    price       = 1200,
    minSpeed    = 8.0,    -- m/s
    minBrake    = 0.6,    -- fren pedalı bundan fazla basılıysa devrede
    latStrength = 11.0,
    yawStrength = 8.0,
}

-- ===== Motor sesleri =====
-- audio: ForceVehicleEngineAudio'ya verilen ses adı, group: OEM | GTA V | DLC
-- DLC olanların audio adlarını kendi ses paketine göre düzenle
Config.Sounds = {
    { id = 'oem',       group = 'OEM',   label = 'Original Vehicle Sound',        sub = nil,            eng = nil,      audio = nil,        price = 0 },

    { id = 'sanchez',   group = 'GTA V', label = '2-Stroke Dirt Bike',            sub = 'Sanchez',      eng = '2T',     audio = 'sanchez',   price = 1000 },
    { id = 'sadler',    group = 'GTA V', label = 'Heavy Duty Diesel Truck',       sub = 'Sadler',       eng = 'DIESEL', audio = 'sadler',    price = 1200 },
    { id = 'vtec',      group = 'GTA V', label = 'Honda High-Rev VTEC',           sub = 'S2000 / Blista', eng = 'I4',   audio = 'bilista',   price = 1500 },
    { id = 'elegy',     group = 'GTA V', label = 'Nissan RB26DETT Twin Turbo',    sub = 'Elegy',        eng = 'I6',     audio = 'elegy',     price = 2500 },
    { id = 'banshee',   group = 'GTA V', label = 'Rotary 13B Turbo',              sub = 'Banshee',      eng = 'ROTARY', audio = 'banshee',   price = 2500 },
    { id = 'akuma',     group = 'GTA V', label = 'Superbike 1000cc',              sub = 'Akuma',        eng = 'I4',     audio = 'akuma',     price = 1500 },
    { id = 'jester',    group = 'GTA V', label = 'Toyota 2JZ-GTE Turbo',          sub = 'Jester',       eng = 'I6',     audio = 'jester',    price = 2500 },
    { id = 'futo',      group = 'GTA V', label = 'Toyota AE86 4AGE NA',           sub = 'Futo',         eng = 'I4',     audio = 'futo',      price = 1500 },
    { id = 'zentorno',  group = 'GTA V', label = 'V10 Supercar High-Rev',         sub = 'Zentorno',     eng = 'V10',    audio = 'zentorno',  price = 2500 },
    { id = 't20',       group = 'GTA V', label = 'V12 Hypercar Twin Turbo',       sub = 'T20',          eng = 'V12',    audio = 't20',       price = 3000 },
    { id = 'coquette',  group = 'GTA V', label = 'V8 Exotic High-Rev',            sub = 'Coquette',     eng = 'V8',     audio = 'coquette',  price = 2500 },
    { id = 'dominator', group = 'GTA V', label = 'V8 Supercharged Muscle',        sub = 'Dominator',    eng = 'V8',     audio = 'dominator', price = 2000 },

    { id = 'r8',        group = 'DLC',   label = 'Audi R8 / Lambo Twin Turbo 5.2L V10', sub = nil,      eng = 'V10',    audio = 'audir8',    price = 4000 },
    { id = 'm4',        group = 'DLC',   label = 'BMW M4 S55 Akrapovic Exhaust',  sub = nil,            eng = 'I6',     audio = 'bmwm4',     price = 4000 },
    { id = 'p60',       group = 'DLC',   label = 'BMW P60B40 4.0L V8 Race Engine', sub = nil,           eng = 'V8',     audio = 'p60b40',    price = 4000 },
    { id = 'veyron',    group = 'DLC',   label = 'Bugatti Veyron 8.0L W16',       sub = nil,            eng = 'W16',    audio = 'veyron',    price = 5000 },
    { id = 'rx7',       group = 'DLC',   label = 'Mazda 13B-REW Twin Rotor',      sub = nil,            eng = 'ROTARY', audio = 'rx7',       price = 4000 },
    { id = 'skyline',   group = 'DLC',   label = 'Nissan Skyline RB26DETT 2.6L I6', sub = nil,         eng = 'I6',     audio = 'rb26dett',  price = 4000 },
    { id = 'zondac',    group = 'DLC',   label = 'Pagani Zonda Cinque M297 7.3L V12', sub = nil,       eng = 'V12',    audio = 'zondac12',  price = 5000 },
    { id = 'zondar',    group = 'DLC',   label = 'Pagani Zonda R M297 6.0L V12',  sub = nil,            eng = 'V12',    audio = 'zondar12',  price = 5000 },
}

-- ===== Egzoz & efektler (tabletten kalıcı olarak yazılır) =====
Config.ExhaustFx = {
    flutter = { label = 'Turbo Flutter', desc = 'Downpipe "stu-tu-tu" sound on throttle lift', price = 800 },
    smoke   = { label = 'Black Smoke',   desc = 'Thick black smoke on throttle',              price = 600 },
    valve   = { label = 'Exhaust Valve', desc = 'Raw sound when open. Flutter, smoke & popcorn only work while it is open (car remote)', price = 1200 },
}
Config.ExhaustFxOrder = { 'flutter', 'smoke', 'valve' }

-- ===== Sürüş modları (araç kumandası) =====
Config.Modes = {
    eco     = { label = 'Eco',     power = -6.0, response = 1.18, shift = 0.90, topSpeed = 0.94, pops = false },
    normal  = { label = 'Comfort', power = 0.0,  response = 1.00, shift = 1.00, topSpeed = 1.00, pops = false },
    sport   = { label = 'Sport',   power = 5.0,  response = 0.92, shift = 1.15, topSpeed = 1.02, pops = true },
    sportp  = { label = 'Sport+',  power = 10.0, response = 0.86, shift = 1.30, topSpeed = 1.05, pops = true },
}
Config.ModeOrder = { 'eco', 'normal', 'sport', 'sportp' }

-- ===== Air Suspension =====
-- Level 1 = en alçak, Level 5 = normal yükseklik. Kit tablette SUSPENSION sekmesinden satın alınır, kumandadan (AIR) yönetilir.
-- Üç yöntem birlikte çalışır (hangisi araçta işe yararsa): araç "Suspension" modu (kademeli, herkes görür),
-- fSuspensionRaise ile yumuşak geçiş animasyonu ve alçalınca otomatik kamber.
Config.Air = {
    price          = 15000,
    levels         = 5,
    requireKit     = true,   -- false = kit satın almadan herkesin aracında çalışır
    useSuspensionMod = true, -- araç modu 15 (Suspension): garanti ve herkes tarafından görünür
    useRaise       = true,   -- fSuspensionRaise ile ek, yumuşak alçalma
    lowestRaise    = -0.10,  -- Level 1'de fSuspensionRaise'a eklenen değer (çok alçalırsa küçült, örn. -0.07)
    camber         = 0.18,   -- Level 1'de tekerlek kamber açısı (radyan)
    camberSign     = 1,      -- kamber ters dönüyorsa -1 yap
    transition     = 1.4,    -- saniye: bir seviye değişiminin süresi (yavaşça iner/çıkar)
    refreshMs      = 110,    -- animasyon sırasında süspansiyonu yenileme aralığı (ms)
    autoRaiseSpeed = 27.0,   -- m/s (~100 km/h): bu hızın üstünde araç kendini yükseltir
    autoRaiseLevel = 3,      -- yüksek hızda en az bu seviyeye çıkar
    autoRaiseHysteresis = 4.0, -- m/s: seviye bu kadar yavaşlayınca eski haline döner (titreşmeyi önler)
}

-- ===== Çekiş kontrolü & ESP simülasyonu =====
Config.ESP = {
    offTractionLoss = 1.55,   -- ESP kapalıyken fTractionLossMult çarpanı (daha kolay kayar)
    assistAngle     = 14.0,   -- ESP açıkken müdahale eden kayma açısı (derece)
    assistStrength  = 0.07,   -- her karede dönüş hızından kesilen oran
    minSpeed        = 12.0,   -- m/s altında müdahale yok
}

Config.TC = {
    enabled     = true,
    launchMin   = 0.92,  -- duruştan kalkışta başlangıç güç oranı (1.0 = sınırsız), hızlı kalkış için yüksek
    launchSpeed = 12.0,  -- m/s: bu hıza kadar kalkış oranı uygulanır
    slipTarget  = 1.1,   -- m/s: izin verilen tekerlek kayması
    slipGain    = 0.35,  -- kayma aşıldıkça güç ne kadar kısılır
    minFactor   = 0.40,  -- güç en fazla bu orana kadar kısılır
    maxRatio    = 0.22,  -- hız arttıkça izin verilen kayma da artar (hızın %22'si). Yüksek hızda güç kesmeyi önler
    response    = 14.0,  -- ayarın hızı (yüksek = daha anlık)
}

-- Kalkış desteği: düz kalkışta yanlamayı/savrulmayı söndürür (ESP kapalıyken de çalışır, el freni ve direksiyonla bozulur)
Config.Launch = {
    enabled     = true,
    maxSpeed    = 34.0,  -- m/s (~120 km/h) altında devrede
    minThrottle = 0.30,
    steerLimit  = 0.45,  -- direksiyon bundan fazla çevrilirse destek çekilir (viraj/drift serbest)
    latStrength = 14.0,  -- yanal kaymayı yok etme gücü
    yawStrength = 9.0,   -- dönme (savrulma) sönümleme gücü
}


-- ===== Kalkış menüsü (tablet > LAUNCH) =====
-- power: kalkış gücü (0-100), slip: patinaj miktarı (0 = hiç patinaj, 100 = burnout)
Config.LaunchMenu = {
    price        = 0,
    defaultPower = 70,
    defaultSlip  = 0,
    launchMinLow = 0.45,   -- power 0'da kalkış güç oranı (power 100'de 1.0)
    boostMin     = 0.60,   -- power 0'da duruştan güç çarpanı
    boostMax     = 1.25,   -- power 100'de duruştan güç çarpanı (kalkışta ekstra)
    slipTargetMax = 9.0,   -- slip 100'de izin verilen tekerlek kayması (m/s)
    slipGainMin   = 0.04,  -- slip 100'de kayma başına güç kısma
    maxSlipTraction = 2.2, -- slip 100'de fLowSpeedTractionLossMult
    presets = {
        { id = 'smooth',  label = 'Smooth',  power = 35,  slip = 0 },
        { id = 'street',  label = 'Street',  power = 60,  slip = 0 },
        { id = 'sport',   label = 'Sport',   power = 80,  slip = 8 },
        { id = 'drag',    label = 'Drag',    power = 100, slip = 15 },
        { id = 'burnout', label = 'Burnout', power = 100, slip = 90 },
    },
}

-- ===== ECU Settings (tablet > ECU SETTINGS) =====
-- Aracın ECU kalibrasyonunu ince ayarlar. "Apply & Flash ECU" ya da sağdaki FLASH ECU ile araca yazılır.
Config.EcuTune = {
    price      = 0,      -- ayarlar değişip flash'lanınca bir kez alınır (0 = ücretsiz)
    redlineRpm = 9000,   -- RPM değerlerinin oyunun 0-1 devir değerine çevrildiği kırmızı çizgi

    defaults = {
        fuel       = 50,        -- 0 lean .. 50 stoich .. 100 rich
        throttle   = 'street',  -- comfort | street | sport | race | instant
        timing     = 'normal',  -- retarded | normal | advanced
        revLimit   = 9000,      -- RPM (kırmızı çizgiyle aynıysa limiter yok)
        speedLimit = 250,       -- KPH
        speedLimitOff = true,   -- true = hız limitörü devre dışı
        lcRpm      = 2000,      -- launch control RPM (en düşük değer = kapalı)
        als        = false,     -- anti-lag
        pops       = 'street',  -- off | street | sport | race
        engBrake   = 50,        -- % (50 = fabrika, üstü daha fazla motor freni)
        idle       = 750,       -- RPM (750 = fabrika)
    },

    -- resp: fDriveInertia çarpanı (düşük = daha hızlı devir), power: ek güç
    throttle = {
        comfort = { label = 'Comfort', resp = 1.20, power = -3.0 },
        street  = { label = 'Street',  resp = 1.00, power = 0.0 },
        sport   = { label = 'Sport',   resp = 0.90, power = 3.0 },
        race    = { label = 'Race',    resp = 0.80, power = 6.0 },
        instant = { label = 'Instant', resp = 0.68, power = 9.0 },
    },
    throttleOrder = { 'comfort', 'street', 'sport', 'race', 'instant' },

    -- Yakıt haritası: (değer - 50) * powerPerStep kadar güç, heatPerStep kadar ısınma
    fuel = { powerPerStep = 0.12, heatPerStep = 0.005 },

    -- Ateşleme: power ek güç, heat ısınma çarpanı
    timing = {
        retarded = { label = 'Retarded', power = -3.0, heat = 0.80 },
        normal   = { label = 'Normal',   power = 0.0,  heat = 1.00 },
        advanced = { label = 'Advanced', power = 4.0,  heat = 1.30 },
    },
    timingOrder = { 'retarded', 'normal', 'advanced' },

    revLimitTopGearOnly = true,   -- devir limitörü sadece son viteste yakıt keser (alt viteslerde vites atmayı engellemez)
    revLimit   = { min = 6000, max = 9000, step = 100 },
    speedLimit = { min = 50,   max = 400,  step = 10 },
    lc         = { min = 2000, max = 7000, step = 100, window = 2500, boost = 1.35, testRpm = 4500 },   -- min = kapalı; kalkışta 2.5 sn ek güç
    idle       = { min = 600,  max = 1500, step = 50, base = 750 },

    -- Pop & Bang seviyeleri: chance/cooldown çarpanları (0 = kapalı)
    pops = {
        off    = { label = 'Off',    chance = 0.0, cooldown = 1.0 },
        street = { label = 'Street', chance = 0.6, cooldown = 1.3 },
        sport  = { label = 'Sport',  chance = 1.0, cooldown = 1.0 },
        race   = { label = 'Race',   chance = 1.6, cooldown = 0.7 },
    },
    popsOrder = { 'off', 'street', 'sport', 'race' },

    engBrakeForce = 0.25,   -- %100'de saniyede yavaşlama oranı (50% = fabrika)
}

-- ===== Turbo kitleri (tablet > EXHAUST) =====
-- boost: basınç çarpanı, spool: dolum süresi çarpanı (küçük = hızlı dolar), pitch/whine: turbo sesinin karakteri
Config.Turbo = {
    kits = {
        stock = { label = 'Stock Turbo',  desc = 'Factory setup. Follows the selected stage.',                       price = 0,     boost = 1.00, spool = 1.00, pitch = 1.00, whine = 1.00, twin = false },
        sport = { label = 'Sport Turbo',  desc = 'Small turbo. Spools fast, high-pitched whistle.',                  price = 4500,  boost = 1.15, spool = 0.72, pitch = 1.35, whine = 1.10, twin = false },
        race  = { label = 'Race Turbo',   desc = 'Big turbo. Slow spool, huge pull, deep whoosh.',                   price = 9000,  boost = 1.55, spool = 1.30, pitch = 0.78, whine = 0.90, twin = false },
        twin  = { label = 'Twin Turbo',   desc = 'Two turbos. Quick spool and strong top-end, layered whine.',       price = 14000, boost = 1.85, spool = 0.90, pitch = 1.05, whine = 1.20, twin = true  },
    },
    order = { 'stock', 'sport', 'race', 'twin' },
    baseNoStage = { boost = 0.45, spool = 1300 },  -- turbo kiti stock yazılımda takılıysa kullanılan temel değerler
    kick  = 24.0,   -- basınç^2 başına ek güç: turbo dolunca araç bir anda basar
    torque = 0.12,
    shake = true,   -- tam basınca hafif kamera sarsıntısı
    -- Ses: oyunun kendi turbo sesi (native varsa) kullanılır; yoksa NUI'de basınca bağlı sürekli ses çalar.
    -- Gerçek kayıt istersen web/sounds/ içine turbo_loop.ogg ve blowoff_real.ogg koy, otomatik kullanılır.
    synth = 'auto',  -- 'auto' | true | false
}

-- ===== Radyo =====
-- Araca binince / motor çalışınca radyo kendiliğinden açılmasın (istersen elle açarsın)
Config.Radio = { autoOff = true }

-- ===== 0-100 testi (Launch Control) =====
Config.LaunchTest = {
    speed100 = 100.0,   -- km/h
    speed60  = 60.0,
    timeout  = 90000,   -- ms: test hazırda bekleyebileceği süre
    hudMs    = 7000,    -- sonuç ekranda ne kadar kalsın
    maxRuns  = 8,       -- tablette tutulan son sonuç sayısı
}

-- ===== ECU Kilidi (flash sırasında güvenlik mini oyunu) =====
-- FLASH ECU'ya basınca terminal açılır, "ECU Güvenlik Anahtarı" mini oyunu geçilmeden araca yazılmaz.
-- Kural: hedef diziyi buffer'a yaz. İlk seçim en üst satırdan, sonra sırayla sütun <-> satır.
Config.EcuLock = {
    enabled     = true,
    time        = 15.0,    -- saniye
    buffer      = 6,       -- buffer yuvası
    grid        = 5,       -- 5x5 tablo
    codes       = { '55', 'E9', 'FF', '1C', 'BD', '7A' },
    -- Hedef dizi uzunluğu seçilen stage'e göre (yüksek stage = daha zor)
    lengthByStage = { stock = 3, stage1 = 3, stage2 = 3, stage3 = 4, stage4 = 5 },
    minMs       = 1500,    -- sunucu: bundan hızlı bitirilen deneme geçersiz sayılır
    ticketSeconds = 90,    -- minigame geçildikten sonra flash için geçerlilik süresi
    lockoutSeconds = 6,    -- başarısızlıktan sonra tekrar deneme bekleme süresi
    skipJobs    = {},      -- {'mechanic'} -> bu meslekler mini oyunsuz flash yapar
}

-- ===== Efektler =====
Config.Effects = {
    -- Kara duman: egzoz uçlarında siyaha boyanmış döngülü partikül (listedeki hepsi üst üste çalışır)
    smokeFx          = { 'exp_grd_bzgas_smoke', 'exp_grd_grenade_smoke' },
    smokeColor       = { 0.0, 0.0, 0.0 },   -- RGB (0-1), siyah
    smokeScale       = 1.8,
    smokeMinThrottle = 0.55,

    -- Popcorn (pops & bangs) aralığı: cooldown + rastgele ek süre (ms)
    popMinRpm    = 0.62,
    popCooldown  = 420,
    popJitter    = 260,
    popChance    = 0.45,

    -- Flutter / blow-off: sadece yüksek devirde tam gaz giderken bir anda gaz kesilince, tek sefer
    flutter = {
        minRpm        = 0.72,   -- gaz kesilirken en az bu devirde olmalı
        minHold       = 700,    -- ms: bundan uzun süre tam gaz tutulmuş olmalı
        suddenMs      = 350,    -- ms: tam gazdan bu süre içinde kesilmeli
        minSpeed      = 12.0,   -- m/s
        cooldown      = 3000,   -- ms: iki ses arası
        volume        = 0.22,   -- flutter sesi (0-1), düşük
        blowoffVolume = 0.28,
    },

    -- Egzoz vanası kapalıyken (kumanda) egzoz stok gibi çalışır: flutter, duman, popcorn kapanır.
    -- true ise vana kapalıyken motor sesi de orijinale döner (sadece vana takılıysa).
    closedValveStockSound = true,

    heatPerSecond = 0.012,
    engineDamageAtFullHeat = true,
    heatMinHealth = 650.0,      -- motor sağlığı bunun altına inmez (oyunun varsayılan beyaz dumanı çıkmasın)
}

-- ===== Dyno =====
Config.Dyno = {
    duration    = 8000,
    hpScale     = 0.95,  -- fInitialDriveForce * fMass * hpScale = tahmini stock HP
    torquePerHp = 1.25,  -- Nm/HP oranı
    peakRpm     = 0.55,
}
